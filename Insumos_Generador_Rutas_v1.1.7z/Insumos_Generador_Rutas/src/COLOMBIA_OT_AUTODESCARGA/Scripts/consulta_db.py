from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QFileDialog, QLabel
from PySide6.QtCore import Qt, QTimer
import pandas as pd
import sqlite3
import os
import sys

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Selector de Archivo Excel")
        self.setFixedSize(400, 200)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        title_label = QLabel("Carga de Municipios")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 16px; font-weight: bold; margin: 20px;")
        
        self.select_button = QPushButton("Seleccionar archivo Excel")
        self.select_button.setFixedSize(200, 40)
        self.select_button.setStyleSheet("""
            QPushButton {
                background-color: #0d6efd;
                color: white;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0b5ed7;
            }
        """)
        self.select_button.clicked.connect(self.select_file)
        
        layout.addWidget(title_label)
        layout.addWidget(self.select_button, alignment=Qt.AlignCenter)
        layout.setContentsMargins(20, 20, 20, 20)

    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecciona el archivo Excel",
            "",
            "Excel files (*.xlsx *.xls)"
        )
        if file_path:
            QTimer.singleShot(100, lambda: self.process_file(file_path))

    def process_file(self, excel_path):
        try:
            df = pd.read_excel(excel_path)
            if df.shape[1] < 2:
                return

            municipios = df.iloc[:, 0].tolist()
            departamentos = df.iloc[:, 1].tolist()

            if any(pd.isna(municipios)) or any(pd.isna(departamentos)):
                return

            db_path = self.get_db_path()
            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()
                self.check_and_update_table_structure(conn, cursor)
                self.limpiar_tablas(conn, cursor)
                datos = list(zip(municipios, departamentos))
                self.insertar_datos(conn, cursor, datos)
                QTimer.singleShot(100, self.close)

        except Exception as e:
            print(f"Error: {str(e)}")

    def check_and_update_table_structure(self, conn, cursor):
        # Paste your existing method here
        pass

    def get_db_path(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(current_dir)
        db_dir = os.path.join(parent_dir, 'db')
        return os.path.join(db_dir, 'Consultas.db')

    def limpiar_tablas(self, conn, cursor):
        cursor.execute("DELETE FROM municipios_tab")
        cursor.execute("DELETE FROM municipios_tab_replica")
        conn.commit()

    def insertar_datos(self, conn, cursor, datos):
        cursor.executemany(
            "INSERT INTO municipios_tab (municipio, departamento) VALUES (?, ?)", 
            datos
        )
        cursor.executemany(
            "INSERT INTO municipios_tab_replica (municipio, departamento) VALUES (?, ?)", 
            datos
        )
        conn.commit()

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()