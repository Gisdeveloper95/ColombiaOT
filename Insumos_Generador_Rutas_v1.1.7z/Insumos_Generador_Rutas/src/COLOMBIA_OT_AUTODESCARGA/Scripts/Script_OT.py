# -*- coding: utf-8 -*-
import os
import sys
import random
import shutil
from selenium import webdriver
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, TimeoutException, NoSuchWindowException
from selenium.common.exceptions import ElementNotInteractableException
from selenium.webdriver.common.action_chains import ActionChains
import time
import sqlite3
import multiprocessing
import threading

import psutil
import signal
import platform
from pathlib import Path
from datetime import datetime

# Variables globales para el control de procesos
municipios_pendientes = multiprocessing.Value('i', 0)  # Contador compartido
terminar_procesos = multiprocessing.Event()  # Evento para señalar la terminación

def human_like_delay():
    time.sleep(random.uniform(1.5, 4))

def random_mouse_movement(driver):
    """Movimiento seguro del mouse dentro de los límites de la ventana"""
    viewport_width = driver.execute_script("return window.innerWidth;")
    viewport_height = driver.execute_script("return window.innerHeight;")
    
    # Mantener el movimiento dentro de límites seguros
    x_offset = random.randint(-min(100, viewport_width//4), min(100, viewport_width//4))
    y_offset = random.randint(-min(100, viewport_height//4), min(100, viewport_height//4))
    
    action = ActionChains(driver)
    action.move_by_offset(x_offset, y_offset).perform()
    human_like_delay()
def simulate_human_behavior(driver):
    random_mouse_movement(driver)
    if random.random() < 0.3:  # 30% de probabilidad de hacer scroll
        driver.execute_script(f"window.scrollTo(0, {random.randint(100, 500)});")
    human_like_delay()

# Agregar estas funciones que faltaron y son importantes:

def is_process_running(pid):
    """Verifica si un proceso está todavía ejecutándose"""
    try:
        return psutil.pid_exists(pid)
    except:
        return False

def cleanup_temp_folders():
    """Limpia las carpetas temporales al inicio"""
    temp_dir = os.path.join(os.getcwd(), 'temp')
    if os.path.exists(temp_dir):
        try:
            shutil.rmtree(temp_dir)
            print("Carpetas temporales limpiadas exitosamente")
        except Exception as e:
            print(f"Error al limpiar carpetas temporales: {str(e)}")

def verify_firefox_installation():
    """Verifica que Firefox esté instalado y accesible"""
    try:
        options = FirefoxOptions()
        driver = webdriver.Firefox(options=options)
        driver.quit()
        return True
    except Exception as e:
        print(f"Error al verificar Firefox: {str(e)}")
        print("Por favor, asegúrate de que Firefox esté instalado correctamente")
        return False

# Modificar setup_driver para incluir más configuraciones importantes:





def human_like_input(element, text):
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(0.05, 0.1))


def iniciar_sesion(driver, usuario, contraseña):
    ventana_original = driver.current_window_handle
    WebDriverWait(driver, 25).until(EC.element_to_be_clickable((By.XPATH, "/html/body/div[3]/div/div/div[3]/a"))).click()
    human_like_delay()
    WebDriverWait(driver, 25).until(EC.element_to_be_clickable((By.ID, "loginBtn"))).click()
    human_like_delay()
    WebDriverWait(driver, 25).until(EC.element_to_be_clickable((By.XPATH, "/html/body/div[5]/div/div/div[2]/div[1]/div/div/div[1]/form/ul/li[4]/button"))).click()
    human_like_delay()
    
    # Esperar y cambiar a la nueva ventana
    WebDriverWait(driver, 10).until(lambda d: len(d.window_handles) > 1)
    driver.switch_to.window(driver.window_handles[-1])

    email_input = WebDriverWait(driver, 25).until(EC.presence_of_element_located((By.NAME, "loginfmt")))
    human_like_input(email_input, usuario)
    email_input.send_keys(Keys.RETURN)
    human_like_delay()

    password_input = WebDriverWait(driver, 25).until(EC.presence_of_element_located((By.NAME, "passwd")))
    human_like_input(password_input, contraseña)
    password_input.send_keys(Keys.RETURN)
    human_like_delay()

    webdriver.ActionChains(driver).send_keys(Keys.RETURN).perform()
    human_like_delay()
    driver.switch_to.window(ventana_original)

def get_db_path():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    db_dir = os.path.join(parent_dir, 'db')
    return os.path.join(db_dir, 'Consultas.db')

def actualizar_total_descargados(municipio, total_descargados):
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE municipios_tab_replica SET total_descargados = ? WHERE municipio = ?", 
                      (total_descargados, municipio))
        conn.commit()
        print(f"Base de datos actualizada para {municipio}")
    except sqlite3.Error as e:
        print(f"Error al actualizar la base de datos: {e}")
    finally:
        conn.close()

def generar_descargas_folder(municipio):
    current_dir = os.path.dirname(os.path.abspath(__file__))  # Scripts
    parent_dir = os.path.dirname(current_dir)  # COLOMBIA_OT_AUTODESCARGA
    project_root = os.path.dirname(parent_dir)  # src
    base_dir = os.path.dirname(project_root)  # Insumos_Generador_Rutas
    descargas_dir = os.path.join(base_dir, 'Descargas', municipio)
    os.makedirs(descargas_dir, exist_ok=True)
    return descargas_dir

def sanitize_filename(filename):
    return filename.replace(':', '-').replace('/', '_').replace('\\', '_')

def cargar_credenciales():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    credentials_file_path = os.path.join(project_root, 'credentials.txt')
    
    with open(credentials_file_path, 'r') as file:
        lines = file.readlines()
        email = lines[0].split(': ')[1].strip()
        password = lines[1].split(': ')[1].strip()
    
    return email, password

def definir_workers():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    workers_file_path = os.path.join(project_root, 'workers_ventanas.txt')
    
    with open(workers_file_path, 'r') as file:
        workers = file.readlines()[0].strip()
        print(f'Cantidad de Ventanas para Consultas: {workers} Ventanas/Workers')
    
    return workers


def paginacion_maxima(driver):
    time.sleep(2)
    try:
        select_rangoMax_documentos = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "#docViewPage > a:nth-child(3)"))
        )
        select_rangoMax_documentos.click()
        human_like_delay()
    except TimeoutException:
        print("Tiempo de espera agotado al buscar el elemento para clic")
    except NoSuchElementException:
        print("No se encontró el elemento para clic")
    except Exception as e:
        print(f"Error inesperado en clic_rango_max_documentos: {str(e)}")

def consultas_descargas(driver, municipio):
    try:
        resultados_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[4]/div[2]/div[1]"))
        )
        resultados_texto = resultados_element.text
        numero_resultados = int(''.join(filter(str.isdigit, resultados_texto)))
        
        print(f"Número de resultados para {municipio}: {numero_resultados}")
        
        db_path = get_db_path()
        conn = None
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("UPDATE municipios_tab_replica SET objetivo_descargas = ? WHERE municipio = ?", 
                         (numero_resultados, municipio))
            conn.commit()
            print(f"Base de datos actualizada exitosamente para {municipio}")
        except sqlite3.Error as e:
            print(f"Error al actualizar la base de datos para {municipio}: {e}")
            if conn:
                conn.rollback()
        finally:
            if conn:
                conn.close()
    
    except TimeoutException:
        print(f"Tiempo de espera agotado al buscar elementos para {municipio}")
    except NoSuchElementException:
        print(f"No se encontró algún elemento necesario para {municipio}")
    except Exception as e:
        print(f"Error inesperado en consultas_descargas para {municipio}: {str(e)}")


def setup_driver(download_path):
    """
    Configuración correcta de Firefox para descargas automáticas
    """
    options = FirefoxOptions()
    
    # Configuración CORRECTA para descargas automáticas
    options.set_preference("browser.download.folderList", 2)
    options.set_preference("browser.download.manager.showWhenStarting", False)
    options.set_preference("browser.download.dir", download_path)
    options.set_preference("browser.helperApps.neverAsk.saveToDisk", 
                         "application/pdf;application/x-pdf;application/octet-stream;" +
                         "application/x-zip-compressed;application/zip;" +
                         "application/msword;application/vnd.ms-excel;" +
                         "application/vnd.openxmlformats-officedocument.wordprocessingml.document;" +
                         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;" +
                         "image/tiff;image/jpeg;image/png;image/x-dwg;application/acad;" +
                         "application/x-prn;application/x-rar-compressed;application/x-7z-compressed")
    
    # Deshabilitar el visor de PDF integrado - ESTO ES CRUCIAL
    options.set_preference("pdfjs.disabled", True)
    options.set_preference("plugin.disable_full_page_plugin_for_types", "application/pdf")
    
    # Forzar descargas
    options.set_preference("browser.download.useDownloadDir", True)
    options.set_preference("browser.download.manager.closeWhenDone", True)
    options.set_preference("browser.download.manager.useWindow", False)
    options.set_preference("browser.download.manager.showAlertOnComplete", False)
    options.set_preference("browser.download.panel.shown", False)
    
    try:
        driver = webdriver.Firefox(options=options)
        driver.set_page_load_timeout(30)
        return driver
    except Exception as e:
        print(f"Error al inicializar Firefox: {str(e)}")
        if 'driver' in locals():
            try:
                driver.quit()
            except:
                pass
        raise

def is_download_completed(temp_dir):
    """
    Verificación mejorada de descarga en Firefox
    """
    for _ in range(10):  # Intentar varias veces
        files = os.listdir(temp_dir)
        if not files:  # No hay archivos aún
            time.sleep(0.5)
            continue
            
        if any(f.endswith('.part') or f.endswith('.tmp') for f in files):
            time.sleep(0.5)
            continue
            
        return True
    return False

def process_cards(driver, descargas_dir, municipio, temp_dir):
    card_index = 1
    archivos_no_procesados = []
    informe_path = os.path.join(os.path.dirname(descargas_dir), 'informe_archivos_no_procesados.txt')

    while True:
        try:
            # Asegurarse que la ventana esté scrolleada a una posición visible
            driver.execute_script(f"window.scrollTo(0, {card_index * 100});")
            human_like_delay()

            card_xpath = f"/html/body/div[2]/div[4]/div[4]/div[{card_index}]"
            card = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, card_xpath)))
            
            # Asegurar que el elemento esté en vista antes de interactuar
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", card)
            time.sleep(1)
            
            # Mover el mouse con offset más pequeño y seguro
            action = ActionChains(driver)
            action.move_to_element(card).perform()  # Primero mover al elemento
            time.sleep(0.5)
            # Pequeño offset aleatorio desde el elemento
            action.move_by_offset(random.randint(-10, 10), random.randint(-10, 10)).perform()
            human_like_delay()

            title_xpath = f"{card_xpath}/div/div[2]/div/div/div[1]/div"
            title_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, title_xpath)))
            title = title_element.text
            print(f" Procesando: {title} Del Municipio: {municipio} - Posicion Actual: {card_index}")

            potential_file_name = sanitize_filename(f"{title}")
            potential_file_path = os.path.join(descargas_dir, potential_file_name)
            
            if any(os.path.exists(f"{potential_file_path}.{ext}") for ext in 
                  ['pdf', 'zip', 'rar', '7z', 'dwg', 'jpg', 'tif', 'tiff', 'prn','bmp','cdr','WOR','xls','xlsx']):
                print(f"Un archivo con el nombre '{potential_file_name}' ya existe. Pasando al siguiente.")
                card_index += 1
                continue

            # Limpiar archivos temporales antes de la descarga
            for file in os.listdir(temp_dir):
                try:
                    os.remove(os.path.join(temp_dir, file))
                except:
                    pass

            # Hacer clic en el botón para descargar
            view_button_xpath = f"{card_xpath}//button[contains(@class, 'btn-default')]"
            view_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, view_button_xpath)))
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", view_button)
            time.sleep(1)
            view_button.click()

            # Esperar la descarga
            max_wait = 7200
            start_time = time.time()
            downloaded_file = None

            while time.time() - start_time < max_wait:
                files = [f for f in os.listdir(temp_dir) 
                        if not f.endswith('.part') and not f.endswith('.tmp')]
                if files:
                    downloaded_file = os.path.join(temp_dir, 
                        max(files, key=lambda f: os.path.getmtime(os.path.join(temp_dir, f))))
                    break
                    
                tiempo_transcurrido = int(time.time() - start_time)
                if tiempo_transcurrido in [120, 360, 3600]:
                    print(f"Esperando descarga para {title}... Tiempo transcurrido: {tiempo_transcurrido} segundos")
                time.sleep(3)

            if downloaded_file:
                time.sleep(2)  # Pequeña espera para asegurar que el archivo esté completo
                file_name = os.path.basename(downloaded_file)
                file_ext = os.path.splitext(file_name)[1]
                new_file_name = sanitize_filename(f"{title}{file_ext}")
                destino_final = os.path.join(descargas_dir, new_file_name)
                
                counter = 1
                while os.path.exists(destino_final):
                    name, ext = os.path.splitext(new_file_name)
                    destino_final = os.path.join(descargas_dir, f"{name}_{counter}{ext}")
                    counter += 1

                shutil.move(downloaded_file, destino_final)
                print(f"Archivo descargado y movido: {new_file_name}")
            else:
                print(f"No se pudo descargar el archivo para: {title}")
                archivos_no_procesados.append(f"{municipio}: {title} - Tiempo de espera agotado")

            card_index += 1
            human_like_delay()

        except (NoSuchElementException, TimeoutException):
            try:
                next_button = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "tableDocumentos_next"))
                )
                
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", next_button)
                time.sleep(1)
                
                if next_button.is_displayed() and next_button.is_enabled() and "disabled" not in next_button.get_attribute("class"):
                    driver.execute_script("arguments[0].click();", next_button)
                    print("Pasando a la siguiente página de resultados.")
                    card_index = 1
                else:
                    print("El botón 'Siguiente' no es visible, habilitado, o está deshabilitado.")
                    break
            except (NoSuchElementException, TimeoutException):
                print("No se encontró el botón 'Siguiente' o no está disponible.")
                break
            except ElementNotInteractableException:
                print("El botón 'Siguiente' no es interactuable en este momento.")
                break

        except Exception as e:
            print(f"Error inesperado: {str(e)}")
            archivos_no_procesados.append(f"{municipio}: Error - {str(e)}")
            continue

    print(f"Consultas para {municipio} completado.")

    total_descargados = len([f for f in os.listdir(descargas_dir) if os.path.isfile(os.path.join(descargas_dir, f))])
    print(f"Total de archivos descargados para {municipio}: {total_descargados}")

    actualizar_total_descargados(municipio, total_descargados)

    with open(informe_path, 'a', encoding='utf-8') as f:
        for archivo in archivos_no_procesados:
            f.write(f"{archivo}\n")

            

def get_next_municipio(lock):
    with lock:
        db_path = get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT municipio, departamento FROM municipios_tab LIMIT 1")
        resultado = cursor.fetchone()
        if resultado:
            municipio, departamento = resultado
            cursor.execute("DELETE FROM municipios_tab WHERE municipio = ? AND departamento = ?", 
                         (municipio, departamento))
            conn.commit()
            municipios_pendientes.value -= 1
            if municipios_pendientes.value == 0:
                terminar_procesos.set()
        conn.close()
        return resultado

def normalize_text(text):
    import unicodedata
    text = text.lower()
    text = ''.join(c for c in unicodedata.normalize('NFD', text)
                  if unicodedata.category(c) != 'Mn')
    return text


def buscar_municipio(driver, municipio, departamento):
    select_field = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "span.select2-selection.select2-selection--single"))
    )
    select_field.click()
    human_like_delay()
    
    search_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "/html/body/span/span/span[1]/input"))
    )
    search_input.clear()
    human_like_input(search_input, municipio)
    human_like_delay()
    
    try:
        results_container = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "select2-results__options"))
        )
        
        municipio_norm = normalize_text(municipio)
        departamento_norm = normalize_text(departamento)
        
        options = results_container.find_elements(By.CLASS_NAME, "select2-results__option")
        
        for option in options:
            muni_span = option.find_element(By.CLASS_NAME, "MUNI")
            texto_completo = muni_span.text
            
            try:
                muni_texto, depto_texto = texto_completo.split(',', 1)
                muni_texto_norm = normalize_text(muni_texto.strip())
                depto_texto_norm = normalize_text(depto_texto.strip())
                
                if (muni_texto_norm == municipio_norm and 
                    depto_texto_norm == departamento_norm):
                    driver.execute_script("arguments[0].scrollIntoView(true);", option)
                    human_like_delay()
                    option.click()
                    return True
                    
            except ValueError:
                continue
        
        print(f"No se encontró coincidencia exacta para {municipio}, {departamento}")
        return False
        
    except TimeoutException:
        print(f"No se encontraron resultados para {municipio}")
        return False



def process_municipio(process_id, lock, delay):
    """
    Mantener la función original pero con ajustes específicos para Firefox
    """
    time.sleep(delay)
    max_retries = 10
    retry_count = 0

    while retry_count < max_retries and not terminar_procesos.is_set():
        try:
            temp_dir = os.path.join(os.getcwd(), 'temp', f'temp{process_id}')
            os.makedirs(temp_dir, exist_ok=True)

            driver = setup_driver(temp_dir)
            
            # Esperar un poco más después de iniciar Firefox
            time.sleep(3)
            
            driver.get("https://www.colombiaot.gov.co/pot/buscador.html")
            usuario, contraseña = cargar_credenciales()
            iniciar_sesion(driver, usuario, contraseña)

            while not terminar_procesos.is_set():
                resultado = get_next_municipio(lock)
                if not resultado:
                    time.sleep(1)
                    continue

                municipio, departamento = resultado
                
                try:
                    driver.get("https://www.colombiaot.gov.co/pot/buscador.html")
                    time.sleep(3)
                    
                    # En Firefox, asegurarnos de que estamos en la ventana correcta
                    if len(driver.window_handles) > 1:
                        driver.switch_to.window(driver.window_handles[0])
                    
                    WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.XPATH, "/html/body/div[3]/div/div/div[3]/a"))
                    ).click()
                    
                    human_like_delay()
                    descargas_dir = generar_descargas_folder(municipio)
                    
                    if not buscar_municipio(driver, municipio, departamento):
                        print(f"Proceso {process_id}: No se pudo seleccionar correctamente {municipio}, {departamento}")
                        with lock:
                            db_path = get_db_path()
                            conn = sqlite3.connect(db_path)
                            cursor = conn.cursor()
                            cursor.execute(
                                "INSERT INTO municipios_tab (municipio, departamento) VALUES (?, ?)", 
                                (municipio, departamento)
                            )
                            conn.commit()
                            conn.close()
                            municipios_pendientes.value += 1
                        continue
                    
                    print(f"Proceso {process_id}: Búsqueda realizada para: {municipio}, {departamento}")
                    paginacion_maxima(driver)
                    consultas_descargas(driver, municipio)
                    process_cards(driver, descargas_dir, municipio, temp_dir)
                    
                except Exception as e:
                    print(f"Proceso {process_id}: Error al procesar el municipio {municipio}, {departamento}: {str(e)}")
                    with lock:
                        db_path = get_db_path()
                        conn = sqlite3.connect(db_path)
                        cursor = conn.cursor()
                        cursor.execute(
                            "INSERT INTO municipios_tab (municipio, departamento) VALUES (?, ?)", 
                            (municipio, departamento)
                        )
                        conn.commit()
                        conn.close()
                        municipios_pendientes.value += 1
                    continue

            driver.quit()
            shutil.rmtree(temp_dir)
            print(f"Proceso {process_id} completado con éxito.")
            break

        except Exception as e:
            retry_count += 1
            print(f"Proceso {process_id} falló. Intento {retry_count} de {max_retries}. Error: {str(e)}")
            try:
                driver.quit()
            except:
                pass
            try:
                shutil.rmtree(temp_dir)
            except:
                pass
            time.sleep(5)  # Reducido a 5 segundos para no esperar tanto

    if retry_count == max_retries:
        print(f"Proceso {process_id} falló después de {max_retries} intentos.")



def main():
    
    cleanup_temp_folders()
    # Configurar el manejo de excepciones no capturadas
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        print("Error no capturado:", str(exc_value))
    
    sys.excepthook = handle_exception
    
    # Inicializar los procesos
    num_processes = int(definir_workers())
    lock = multiprocessing.Lock()

    # Inicializar el contador de municipios pendientes
    with lock:
        db_path = get_db_path()
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM municipios_tab")
        count = cursor.fetchone()[0]
        conn.close()
        municipios_pendientes.value = count

    print(f"Iniciando procesamiento con {num_processes} procesos")
    print(f"Total de municipios a procesar: {municipios_pendientes.value}")

    # Crear y iniciar los procesos
    processes = []
    for i in range(num_processes):
        delay = i * 32  # 32 segundos de retraso entre cada inicio de proceso
        p = multiprocessing.Process(target=process_municipio, args=(i+1, lock, delay))
        processes.append(p)
        p.start()
        print(f"Proceso {i+1} iniciado")

    # Esperar a que todos los procesos terminen
    for p in processes:
        p.join()

    print("\nTodos los procesos han terminado.")
    print("Resumen final:")
    print(f"Total de municipios procesados: {count - municipios_pendientes.value}")
    print(f"Municipios pendientes: {municipios_pendientes.value}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nProceso interrumpido por el usuario")
        sys.exit(1)
    except Exception as e:
        print(f"\nError crítico: {str(e)}")
        sys.exit(1)