
import sys
import os
from pathlib import Path
import shutil
import subprocess
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,QWidget,QTextEdit,QProgressBar,QTabWidget,QTableWidget,
    QListWidget, QLineEdit, QFrame, QListWidgetItem, QMainWindow,QApplication, QStatusBar,QMessageBox,QTableWidgetItem, QHBoxLayout
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
import sqlite3
import pandas as pd
from datetime import datetime
import logging
import json
from filter_handler import FilterHandler



# Configurar las rutas correctamente
SCRIPT_DIR = Path(__file__).parent
SRC_DIR = SCRIPT_DIR.parent  # src directory
COLOMBIA_OT_DIR = os.path.join(SRC_DIR, "COLOMBIA_OT_AUTODESCARGA", "Scripts")
# Agregar el directorio al path de Python
if COLOMBIA_OT_DIR not in sys.path:
    sys.path.insert(0, str(COLOMBIA_OT_DIR))

from Main2 import SecondTabComponent


def check_firefox_installation():
    """
    Verifica la instalación de Firefox de manera más robusta
    Retorna: (bool, str) - (está_instalado, mensaje_error)
    """
    import os
    import platform
    
    try:
        system = platform.system()
        
        if system == 'Windows':
            # Buscar en las ubicaciones comunes de Windows
            common_locations = [
                os.path.expandvars(r'%ProgramFiles%\Mozilla Firefox\firefox.exe'),
                os.path.expandvars(r'%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe'),
                os.path.expandvars(r'%LocalAppData%\Mozilla Firefox\firefox.exe')
            ]
            
            for location in common_locations:
                if os.path.isfile(location):
                    return True, ""
                    
            # Intentar encontrar usando where
            try:
                result = subprocess.run(['where', 'firefox'], 
                                     capture_output=True, 
                                     text=True)
                if result.returncode == 0 and result.stdout.strip():
                    return True, ""
            except:
                pass
                
        elif system in ['Linux', 'Darwin']:
            # En Linux/Mac usar which
            try:
                result = subprocess.run(['which', 'firefox'], 
                                     capture_output=True, 
                                     text=True)
                if result.returncode == 0:
                    return True, ""
            except:
                pass
        
        # Si llegamos aquí, no se encontró Firefox
        return False, "No se pudo encontrar Firefox en las ubicaciones habituales."
        
    except Exception as e:
        return False, f"Error al verificar Firefox: {str(e)}"
    
class FilterButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setObjectName("filterButton")
        self._selected = False
        self._apply_style()

    def set_selected(self, selected):
        self._selected = selected
        self._apply_style()

    def _apply_style(self):
        button_text_color = "#E8E6E3"
        accent_color = "#A67C52"
        
        if self._selected:
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color: {accent_color};
                    color: {button_text_color};
                    border: none;
                    text-align: center;
                    padding: 10px;
                    font-weight: bold;
                    margin: 5px 0;
                    border-radius: 6px;
                }}
                QPushButton:hover {{
                    background-color: rgba(166, 124, 82, 0.8);
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color: rgba(166, 124, 82, 0.1);
                    color: {button_text_color};
                    border: 1px solid {accent_color};
                    text-align: center;
                    padding: 10px;
                    font-weight: normal;
                    margin: 5px 0;
                    border-radius: 6px;
                }}
                QPushButton:hover {{
                    background-color: rgba(166, 124, 82, 0.3);
                }}
            """)
class EnterpriseFilterWidget(QFrame):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.setObjectName("filterFrame")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)
        
        title_label = QLabel(title)
        title_label.setObjectName("filterTitle")
        layout.addWidget(title_label)
        
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Buscar...")
        self.search_box.textChanged.connect(self._filter_items)
        layout.addWidget(self.search_box)
        
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QListWidget.ExtendedSelection)
        layout.addWidget(self.list_widget)
        
        btn_layout = QHBoxLayout()
        self.select_all_btn = QPushButton("Seleccionar Todo")
        self.select_all_btn.clicked.connect(self._select_all)
        btn_layout.addWidget(self.select_all_btn)
        
        self.clear_btn = QPushButton("Limpiar")
        self.clear_btn.clicked.connect(self._clear_selection)
        btn_layout.addWidget(self.clear_btn)
        
        layout.addLayout(btn_layout)
        
        self.count_label = QLabel("0 elementos seleccionados")
        layout.addWidget(self.count_label)
        
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #dddddd;
                border-radius: 5px;
            }
            QLabel#filterTitle {
                font-weight: bold;
                color: #1a237e;
                padding: 5px 0;
            }
            QLineEdit {
                padding: 5px;
                border: 1px solid #dddddd;
                border-radius: 4px;
            }
            QListWidget {
                border: 1px solid #dddddd;
                border-radius: 4px;
                padding: 2px;
                background-color: white;
                min-height: 150px;
            }
            QListWidget::item {
                padding: 5px;
                border-radius: 2px;
            }
            QListWidget::item:selected {
                background-color: #e3f2fd;
                color: #1a237e;
            }
            QListWidget::item:hover {
                background-color: #f5f5f5;
            }
            QPushButton {
                padding: 5px 10px;
                background-color: #1a237e;
                color: white;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #283593;
            }
        """)

    def _filter_items(self, text):
        search_text = text.lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item.setHidden(search_text not in item.text().lower())

    def _select_all(self):
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if not item.isHidden():
                item.setSelected(True)
        self._update_count()

    def _clear_selection(self):
        self.list_widget.clearSelection()
        self._update_count()

    def _update_count(self):
        count = len(self.list_widget.selectedItems())
        self.count_label.setText(f"{count} elementos seleccionados")

    def populate_items(self, items):
        if items is None:
            return
        
        self.list_widget.clear()
        for item in sorted(set(str(x) for x in items if x is not None and str(x).strip())):
            self.list_widget.addItem(item)
        self._update_count()

    def get_selected_items(self):
        return [item.text() for item in self.list_widget.selectedItems()]


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistema de Gestión de Insumos - IGAC  Subdireccion de Proyectos ~ andres.osorio@igac.gov.co")
        self.setMinimumSize(900, 700)
        
        # Inicializar central_widget
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Definir los mapeos como atributos de la clase
        self.column_mapping = {
            'departamento': 'DEPARTAMENTO',
            'municipio': 'MUNICIPIO',
            'modelo': 'MODELO DE OPERACIÓN',
            'mecanismo': 'MECANISMO DE GESTIÓN DE RECURSOS',
            'propuesta_cierre': 'propuesta_cierre'
        }
        
        self.title_mapping = {
            'departamento': 'Seleccionar Departamentos',
            'municipio': 'Seleccionar Municipios',
            'modelo': 'Seleccionar Modelos de Operación',
            'mecanismo': 'Seleccionar Mecanismos de Gestión',
            'propuesta_cierre': 'Seleccionar Propuesta Cierre 2024'
        }
        
        # Mapeo de valores para propuesta_cierre
        self.propuesta_cierre_labels = {
            "1": "1 - Cierre Presente Año",
            "0": "0 - Cierre 2025"
        }
        
        # Initialize data storage
        self.df = None
        self.selected_filters = {
            'municipio': [],
            'departamento': [],
            'modelo': [],
            'mecanismo': [],
            'propuesta_cierre': []
        }
        
        self.setup_ui()
        self.setup_paths()
        self.apply_styles()
        
        self.log_info("Sistema iniciado")
        self.log_info("Use 'Actualizar Filtros' para comenzar")

    def apply_selected_button_style(self, button):
        """Aplica el estilo para botones con elementos seleccionados"""
        background_color = "#2D2A24"
        button_text_color = "#E8E6E3"
        accent_color = "#A67C52"
        
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: rgba(166, 124, 82, 0.25);
                color: {button_text_color};
                border: 2px solid {accent_color};
                text-align: center;
                padding: 10px;
                font-weight: normal;
                margin: 5px 0;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: rgba(166, 124, 82, 0.3);
            }}
        """)

    def apply_default_button_style(self, button):
        """Restaura el estilo por defecto de los botones"""
        background_color = "#2D2A24"
        button_text_color = "#E8E6E3"
        accent_color = "#A67C52"
        
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: rgba(166, 124, 82, 0.1);
                color: {button_text_color};
                border: 1px solid {accent_color};
                text-align: center;
                padding: 10px;
                font-weight: normal;
                margin: 5px 0;
                border-radius: 6px;
            }}
            QPushButton:hover {{
                background-color: rgba(166, 124, 82, 0.2);
            }}
        """)
       
    def abrir_resultados_disposicion(self):
        """Abre el directorio de resultados de disposición"""
        if not self.output_dir_post.exists():
            self.log_error("El directorio de resultados de disposición no existe")
            return
            
        try:
            if sys.platform == 'win32':
                os.startfile(self.output_dir_post)
            else:
                self.log_error("Función no soportada en este sistema operativo")
                
        except Exception as e:
            self.log_error(f"Error al abrir directorio: {str(e)}")
    
    def setup_paths(self):
        """Configuración de rutas del sistema"""
        self.script_dir = Path(__file__).parent
        self.root_dir = self.script_dir.parent.parent
        self.plantilla_dir = self.root_dir / "src" / "plantilla_actual"
        self.resultados_dir = self.root_dir / "Resultados"
        self.output_dir_post = self.root_dir / "Resultados_Post"  # Nueva ruta
        
        # Asegurar que ambos directorios de resultados existan
        self.resultados_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir_post.mkdir(parents=True, exist_ok=True)
        
        # No buscar el Excel aquí, solo configurar la ruta
        self.excel_path = None

    def actualizar_insumos(self):
        """Ejecuta el script de actualización y carga los datos"""
        self.log_info("Iniciando actualización de insumos...")
        self.progress_bar.setRange(0, 0)  # Modo indeterminado
        
        try:
            script_path = self.script_dir / "Analizer.py"
            if not script_path.exists():
                raise FileNotFoundError(f"No se encuentra el archivo {script_path}")
            
            # Configurar el entorno para el subproceso
            env = os.environ.copy()
            
            # Agregar rutas de Firefox al PATH
            firefox_paths = [
                r'C:\Program Files\Mozilla Firefox',
                r'C:\Program Files (x86)\Mozilla Firefox',
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Mozilla Firefox')
            ]
            
            # Agregar rutas de Python y TCL/TK
            python_base = os.path.dirname(sys.executable)
            env['PATH'] = os.pathsep.join([
                env.get('PATH', ''),
                *firefox_paths,
                python_base,
                os.path.join(python_base, 'Scripts'),
                os.path.join(python_base, 'Lib'),
                os.path.join(python_base, 'Lib', 'site-packages')
            ])
            
            # Configurar variables de TCL/TK
            env['TCL_LIBRARY'] = os.path.join(python_base, 'tcl', 'tcl8.6')
            env['TK_LIBRARY'] = os.path.join(python_base, 'tcl', 'tk8.6')
            
            # Ejecutar el proceso con el entorno modificado
            process = subprocess.run(
                [sys.executable, str(script_path)],
                capture_output=True,
                text=True,
                env=env
            )
            
            # Procesar la salida
            if process.stdout:
                for line in process.stdout.splitlines():
                    if line.strip():
                        self.log_info(line)
                        
            if process.stderr:
                for line in process.stderr.splitlines():
                    if line.strip():
                        self.log_error(line)
            
            if process.returncode != 0:
                raise subprocess.CalledProcessError(
                    process.returncode,
                    [sys.executable, str(script_path)],
                    process.stdout,
                    process.stderr
                )
                
            self.log_info("Actualización completada")
            self.cargar_datos_excel()
                
        except Exception as e:
            error_msg = str(e)
            self.log_error(f"Error: {error_msg}")
            QMessageBox.critical(
                self,
                "Error",
                error_msg,
                QMessageBox.Ok
            )
            
        finally:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)


    def _populate_filter_options(self):
        """Actualiza las opciones disponibles en los filtros"""
        if self.df is not None:
            try:
                # Mapeo de filtros a columnas
                filter_columns = {
                    'departamento': 'DEPARTAMENTO',
                    'municipio': 'MUNICIPIO',
                    'modelo': 'MODELO DE OPERACIÓN',
                    'mecanismo': 'MECANISMO DE GESTIÓN DE RECURSOS',
                    'propuesta_cierre': 'NUEVA PROPUESTA CIERRE 2024\nPROPUESTO DT'
                }
                
                # Actualizar cada filtro
                for filter_type, column in filter_columns.items():
                    if column in self.df.columns:
                        button = self.filter_buttons.get(filter_type)
                        if button:
                            button.set_selected(False)
                            label = self.findChild(QLabel, f"filterLabel_{filter_type}")
                            if label:
                                label.setText("0 seleccionados")
            except Exception as e:
                self.log_error(f"Error al actualizar opciones de filtros: {str(e)}")

    def cargar_datos_excel(self):
        """Carga los datos del Excel más reciente"""
        try:
            self.limpiar_bases_datos()
            # Buscar el Excel más reciente
            excel_files = list(self.plantilla_dir.glob("*.xlsx"))
            if not excel_files:
                self.log_warning("No se encontró ningún archivo Excel")
                return
                    
            self.excel_path = excel_files[0]
                
            # Primero leemos todas las columnas
            df_raw = pd.read_excel(
                self.excel_path,
                sheet_name='Base_mpios_2024',
                skiprows=4
            )
            
            # Mapeo flexible de nombres de columnas
            column_mappings = {
                'codigo_mpio': ['Código MPIO', 'CÓDIGO MPIO', 'Codigo MPIO', 'CODIGO MPIO'],
                'MUNICIPIO': ['MUNICIPIO', 'Municipio'],
                'DEPARTAMENTO': ['DEPARTAMENTO', 'Departamento'],
                'MODELO DE OPERACIÓN': ['MODELO DE OPERACIÓN', 'Modelo de Operacion', 'MODELO OPERACION'],
                'MECANISMO DE GESTIÓN DE RECURSOS': ['MECANISMO DE GESTIÓN DE RECURSOS', 'Mecanismo de Gestion'],
                'propuesta_cierre': ['NUEVA PROPUESTA CIERRE 2024\nPROPUESTO DT', 'NUEVA PROPUESTA CIERRE 2024 PROPUESTO DT']
            }
            
            # Identificar las columnas correctas
            selected_columns = {}
            for target_col, possible_names in column_mappings.items():
                found = False
                for name in possible_names:
                    if name in df_raw.columns:
                        selected_columns[target_col] = name
                        found = True
                        break
                if not found and target_col != 'propuesta_cierre':
                    self.log_warning(f"No se encontró la columna {target_col} en el Excel")
            
            # Crear una copia explícita del DataFrame con las columnas seleccionadas
            selected_data = df_raw[[selected_columns[col] for col in selected_columns.keys()]].copy()
            
            # Renombrar las columnas
            new_columns = list(selected_columns.keys())
            selected_data.columns = new_columns
            
            # Llenar valores nulos de manera segura usando .loc
            for col in selected_data.columns:
                selected_data.loc[selected_data[col].isna(), col] = 'No especificado'
            
            # Asignar el DataFrame procesado
            self.df = selected_data
            
            self.log_info(f"Datos cargados: {len(self.df)} registros")
            self.log_info(f"Columnas cargadas: {list(self.df.columns)}")
            
            # Limpiar las selecciones anteriores
            self.clear_filters()
            self._populate_filter_options()  # Actualizar las opciones de filtros
        except Exception as e:
            self.log_error(f"Error al cargar datos: {str(e)}")
            import traceback
            self.log_error(traceback.format_exc())
            


    def verificar_resultados(self, count_processed):
        """Verifica que el número de registros procesados coincida con lo esperado"""
        if hasattr(self, 'expected_records') and self.expected_records != count_processed:
            self.log_warning(f"Advertencia: Se esperaban {self.expected_records} registros pero se procesaron {count_processed}")
            return False
        return True

    def show_filter_dialog(self, filter_type):
        """Muestra el diálogo de filtro para el tipo especificado"""
        if self.df is None:
            QMessageBox.warning(
                self,
                "Sin datos",
                "Por favor, actualice los insumos primero para cargar los datos.",
                QMessageBox.Ok
            )
            return

        # Mapeo de tipos de filtro a columnas del DataFrame
        column_mapping = {
            'departamento': 'DEPARTAMENTO',
            'municipio': 'MUNICIPIO',
            'modelo': 'MODELO DE OPERACIÓN',
            'mecanismo': 'MECANISMO DE GESTIÓN DE RECURSOS',
            'propuesta_cierre': 'propuesta_cierre'
        }
        
        title_mapping = {
            'departamento': 'Seleccionar Departamentos',
            'municipio': 'Seleccionar Municipios',
            'modelo': 'Seleccionar Modelos de Operación',
            'mecanismo': 'Seleccionar Mecanismos de Gestión',
            'propuesta_cierre': 'Seleccionar Propuesta Cierre 2024'
        }

        # Mapeo de valores para propuesta_cierre
        propuesta_cierre_labels = {
            "1": "1 - Cierre Presente Año",
            "0": "0 - Cierre 2025"
        }

        try:
            # Verificar que la columna existe en el DataFrame
            column_name = self.column_mapping[filter_type]
            if column_name not in self.df.columns:
                QMessageBox.warning(
                    self,
                    "Error",
                    f"La columna {column_name} no está disponible en los datos cargados.",
                    QMessageBox.Ok
                )
                return

            # Crear una copia del DataFrame para aplicar filtros
            filtered_df = self.df.copy()

            # Aplicar filtros existentes excepto el actual
            for existing_filter, selections in self.selected_filters.items():
                if existing_filter != filter_type and selections:
                    existing_column = column_mapping[existing_filter]
                    if existing_column in filtered_df.columns:
                        # Convertir valores a str para propuesta_cierre si es necesario
                        if existing_filter == 'propuesta_cierre':
                            filtered_df = filtered_df[filtered_df[existing_column].astype(str).isin([str(x) for x in selections])]
                        else:
                            filtered_df = filtered_df[filtered_df[existing_column].isin(selections)]

            # Obtener valores únicos disponibles del DataFrame filtrado
            if filter_type == 'propuesta_cierre':
                # Manejar específicamente la columna propuesta_cierre
                available_items = sorted(filtered_df[column_name].astype(str).unique())
                available_items = [x for x in available_items if x != 'nan' and x.strip()]
                # Convertir valores a etiquetas descriptivas
                display_items = [propuesta_cierre_labels.get(x, x) for x in available_items]
                current_selections = [propuesta_cierre_labels.get(str(x), str(x)) 
                                    for x in self.selected_filters[filter_type]]
            else:
                available_items = sorted(filtered_df[column_name].dropna().unique())
                display_items = available_items
                current_selections = self.selected_filters[filter_type]

            if len(available_items) == 0:
                QMessageBox.warning(
                    self,
                    "Sin opciones",
                    "No hay opciones disponibles con los filtros actuales.",
                    QMessageBox.Ok
                )
                return
            
            # Crear y mostrar el diálogo
            dialog = FilterDialog(
                title_mapping[filter_type],
                display_items,
                current_selections=current_selections,
                value_mapping={v: k for k, v in propuesta_cierre_labels.items()} if filter_type == 'propuesta_cierre' else None,
                parent=self
            )
            
            if dialog.exec() == QDialog.Accepted:
                # Actualizar selecciones
                if filter_type == 'propuesta_cierre':
                    # Convertir las etiquetas seleccionadas de vuelta a valores
                    selected_values = []
                    value_to_label = {v: k for k, v in propuesta_cierre_labels.items()}
                    for item in dialog.get_selected_items():
                        selected_values.append(value_to_label.get(item, item))
                    self.selected_filters[filter_type] = selected_values
                else:
                    self.selected_filters[filter_type] = dialog.get_selected_items()
                
                # Actualizar etiqueta del botón
                count = len(self.selected_filters[filter_type])
                label = self.findChild(QLabel, f"filterLabel_{filter_type}")
                if label:
                    label.setText(f"{count} seleccionados")
                
                # Actualizar estado visual del botón
                button = self.filter_buttons[filter_type]
                if isinstance(button, FilterButton):
                    button.set_selected(count > 0)
                
                # Actualizar la disponibilidad de otros filtros
                filtered_df = self.df.copy()
                for filter_name, selections in self.selected_filters.items():
                    if selections:
                        column = column_mapping[filter_name]
                        if filter_name == 'propuesta_cierre':
                            filtered_df = filtered_df[filtered_df[column].astype(str).isin([str(x) for x in selections])]
                        else:
                            filtered_df = filtered_df[filtered_df[column].isin(selections)]

                # Habilitar/deshabilitar botones según disponibilidad de opciones
                for other_filter in self.filter_buttons:
                    if other_filter != filter_type:
                        other_column = column_mapping[other_filter]
                        unique_values = filtered_df[other_column].dropna().unique()
                        other_button = self.filter_buttons[other_filter]
                        if isinstance(other_button, FilterButton):
                            other_button.setEnabled(len(unique_values) > 0)
                            if len(unique_values) == 0:
                                # Limpiar selección si no hay opciones disponibles
                                self.selected_filters[other_filter] = []
                                label = self.findChild(QLabel, f"filterLabel_{other_filter}")
                                if label:
                                    label.setText("0 seleccionados")
                                other_button.set_selected(False)
                
                self.log_info(f"Filtro {filter_type}: {count} elementos seleccionados")
                
        except Exception as e:
            self.log_error(f"Error al mostrar diálogo de filtro: {str(e)}")
            import traceback
            self.log_error(traceback.format_exc())


    def clear_filters(self):
        """Limpia todos los filtros seleccionados"""
        try:
            self.selected_filters = {
                'municipio': [],
                'departamento': [],
                'modelo': [],
                'mecanismo': [],
                'propuesta_cierre': []
            }
            
            # Restaurar estado visual de los botones y etiquetas
            for filter_type in self.selected_filters:
                # Actualizar etiqueta
                label = self.findChild(QLabel, f"filterLabel_{filter_type}")
                if label:
                    label.setText("0 seleccionados")
                
                # Restaurar estilo del botón
                button = self.filter_buttons.get(filter_type)
                if button and isinstance(button, FilterButton):
                    button.set_selected(False)
                    button.setEnabled(True)  # Asegurarse de que el botón esté habilitado
            
            self.log_info("Filtros limpiados correctamente")
            
        except Exception as e:
            self.log_error(f"Error al limpiar filtros: {str(e)}")

    def clear_directory(self, directory_path):
        """Limpia todo el contenido del directorio especificado"""
        try:
            if directory_path.exists():
                for item in directory_path.iterdir():
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
                self.log_info(f"Directorio limpiado exitosamente: {directory_path}")
        except Exception as e:
            self.log_error(f"Error al limpiar directorio: {str(e)}")



    def verificar_estado_filtros(self):
        """Verifica que los filtros sean consistentes con el DataFrame actual"""
        try:
            if self.df is None:
                return False
                
            # Verificar cada filtro activo
            filtered_df = self.df.copy()
            for filter_type, selections in self.selected_filters.items():
                if selections:
                    column = self.column_mapping[filter_type]
                    if filter_type == 'propuesta_cierre':
                        filtered_df = filtered_df[filtered_df[column].astype(str).isin([str(x) for x in selections])]
                    else:
                        filtered_df = filtered_df[filtered_df[column].isin(selections)]
            
            # Guardar el número de registros que deberían procesarse
            self.expected_records = len(filtered_df)
            return True
            
        except Exception as e:
            self.log_error(f"Error al verificar estado de filtros: {str(e)}")
            return False
    
    def generar_plantillas(self):
        """Genera las plantillas con los filtros seleccionados"""
        if not any(self.selected_filters.values()):
            self.log_error("No hay filtros seleccionados. Por favor, seleccione al menos un filtro.")
            return
        
        if not self.verificar_estado_filtros():
            self.log_error("El estado de los filtros no es consistente. Por favor, actualice los filtros.")
            return
            
        try:
            self.log_info("Iniciando generación de plantillas...")
            self.log_info(f"Se procesarán {self.expected_records} registros según los filtros actuales")
            self.progress_bar.setRange(0, 0)  # Modo indeterminado
            
            # Limpiar el directorio de resultados antes de generar nuevas plantillas
            self.clear_directory(self.resultados_dir)
            
            from pathlib import Path
            import importlib.util
            
            # Rest of the existing code remains the same...
            current_dir = Path(__file__).resolve().parent
            self.log_info(f"Directorio actual: {current_dir}")
            
            filter_handler = FilterHandler()
            filter_handler.save_filters(self.selected_filters)
            
            scripts_to_run = [
                "1_Actualizar_BD_Consulta.py",
                "2_Actualizar_Rutas_Consultas.py",
                "3_Concatenar_DB.py",
                "4_Script.py"
            ]
            
            self.limpiar_bases_datos()
            for script_name in scripts_to_run:
                script_path = current_dir / script_name
                
                if not script_path.exists():
                    self.log_error(f"No se encuentra el script: {script_name}")
                    continue
                    
                self.log_info(f"Ejecutando {script_name}...")
                
                try:
                    spec = importlib.util.spec_from_file_location(
                        script_name.replace(".py", ""),
                        str(script_path)
                    )
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[script_name.replace(".py", "")] = module
                    spec.loader.exec_module(module)
                    
                    if hasattr(module, 'main'):
                        self.log_info(f"Ejecutando main() de {script_name}")
                        module.main()
                    elif "3_Concatenar_DB.py" in script_name:
                        self.log_info("Ejecutando create_new_database()")
                        module.create_new_database()
                    elif "4_Script.py" in script_name:
                        self.log_info("Ejecutando proceso de automatización")
                        automator = module.ExcelAutomator()
                        automator.process_all_municipalities()
                    else:
                        raise Exception(f"No se encontró método de ejecución para {script_name}")
                    
                    self.log_info(f"{script_name} completado correctamente")
                    
                except Exception as e:
                    self.log_error(f"Error en {script_name}: {str(e)}")
                    import traceback
                    self.log_error(traceback.format_exc())
                    return
            
            self.log_info("Proceso completado exitosamente")
            
        except Exception as e:
            self.log_error(f"Error durante la generación: {str(e)}")
            import traceback
            self.log_error(traceback.format_exc())
        finally:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)


    def limpiar_bases_datos(self):
        """Limpia todas las bases de datos antes de una nueva ejecución"""
        try:
            db_files = [
                'municipios.db',
                'rutas.db',
                'registros_totales.db',
                'registros_totales_post.db'
            ]
            
            for db_file in db_files:
                db_path = self.script_dir.parent / 'db' / db_file
                if db_path.exists():
                    try:
                        db_path.unlink()
                        self.log_info(f"Base de datos limpiada: {db_file}")
                    except Exception as e:
                        self.log_error(f"Error al limpiar {db_file}: {str(e)}")
                        
            # Recrear el directorio db si es necesario
            db_dir = self.script_dir.parent / 'db'
            db_dir.mkdir(exist_ok=True)
            
        except Exception as e:
            self.log_error(f"Error durante la limpieza de bases de datos: {str(e)}")


    def abrir_resultados(self):
        """Abre el directorio de resultados"""
        if not self.resultados_dir.exists():
            self.log_error("El directorio de resultados no existe")
            return
            
        try:
            if sys.platform == 'win32':
                os.startfile(self.resultados_dir)
            else:
                self.log_error("Función no soportada en este sistema operativo")
                
        except Exception as e:
            self.log_error(f"Error al abrir directorio: {str(e)}")

    def log_info(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console.append(f"[INFO] {timestamp} - {message}")

    def log_error(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console.append(f"[ERROR] {timestamp} - {message}")

    def log_warning(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.console.append(f"[WARNING] {timestamp} - {message}")

    def create_left_panel(self):
        left_panel = QFrame()
        left_panel.setObjectName("leftPanel")
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)
        
        # Título y botón de actualizar filtros
        header_layout = QHBoxLayout()
        filter_title = QLabel("Filtros de Búsqueda")
        filter_title.setObjectName("sectionTitle")
        header_layout.addWidget(filter_title)
        
        self.btn_actualizar_filtros = QPushButton("Actualizar Filtros")
        self.btn_actualizar_filtros.setObjectName("refreshButton")
        self.btn_actualizar_filtros.clicked.connect(self.cargar_datos_excel)
        header_layout.addWidget(self.btn_actualizar_filtros)
        
        left_layout.addLayout(header_layout)
        
        # Crear filtros
        self.municipio_filter = EnterpriseFilterWidget("Municipio")
        self.departamento_filter = EnterpriseFilterWidget("Departamento")
        self.modelo_filter = EnterpriseFilterWidget("Modelo de Operación")
        self.mecanismo_filter = EnterpriseFilterWidget("Mecanismo de Gestión Recursos")
        
        left_layout.addWidget(self.municipio_filter)
        left_layout.addWidget(self.departamento_filter)
        left_layout.addWidget(self.modelo_filter)
        left_layout.addWidget(self.mecanismo_filter)


    def abrir_directorio_descargas(self):
        """Abre el directorio de descargas"""
        descargas_dir = self.script_dir.parent.parent / "Descargas"
        try:
            if not descargas_dir.exists():
                descargas_dir.mkdir(parents=True, exist_ok=True)
                
            if sys.platform == 'win32':
                os.startfile(descargas_dir)
            else:
                self.log_error("Función no soportada en este sistema operativo")
                
        except Exception as e:
            self.log_error(f"Error al abrir directorio de descargas: {str(e)}")
            
    def setup_ui(self):
        # Configurar el tab widget principal
        self.tab_widget = QTabWidget()
        
        # Primera pestaña (Gestión Base Municipios)
        self.tab1 = QWidget()
        tab1_layout = QHBoxLayout(self.tab1)
        
        # Left panel (Filter buttons)
        left_panel = QFrame()
        left_panel.setObjectName("leftPanel")
        left_layout = QVBoxLayout(left_panel)
        
        # Filter section header with both update buttons
        header_layout = QVBoxLayout()
        filter_title = QLabel("Filtros de Búsqueda")
        filter_title.setObjectName("sectionTitle")
        header_layout.addWidget(filter_title)
        
        # Botón actualizar insumos (arriba)
        self.btn_actualizar = QPushButton("Actualizar Base Municipios")
        self.btn_actualizar.setObjectName("updateButton")
        self.btn_actualizar.setFixedHeight(30)
        header_layout.addWidget(self.btn_actualizar)
        
        # Botón actualizar filtros (abajo)
        self.btn_actualizar_filtros = QPushButton("Actualizar Filtros")
        self.btn_actualizar_filtros.setObjectName("refreshButton")
        self.btn_actualizar_filtros.setFixedHeight(30)
        header_layout.addWidget(self.btn_actualizar_filtros)
        
        left_layout.addLayout(header_layout)
        
        # Filter buttons
        self.filter_buttons = {}
        for filter_name, display_name in [
            ('departamento', 'Departamento'),
            ('municipio', 'Municipio'),
            ('modelo', 'Modelo de Operación'),
            ('mecanismo', 'Mecanismo de Gestión'),
            ('propuesta_cierre', 'NUEVA PROPUESTA CIERRE 2024\nPROPUESTO DT')
        ]:
            # Crear el botón y asignar el nombre de objeto para los estilos
            btn = FilterButton(display_name)
            btn.setObjectName(f"filterButton_{filter_name}")  # Importante para los estilos
            
            # Conectar el evento con una función lambda que preserva el nombre del filtro
            btn.clicked.connect(lambda checked, name=filter_name: self.show_filter_dialog(name))
            
            left_layout.addWidget(btn)
            self.filter_buttons[filter_name] = btn
            
            # Label para el conteo
            label = QLabel("0 seleccionados")
            label.setObjectName(f"filterLabel_{filter_name}")
            left_layout.addWidget(label)
        
        # Right panel
        right_panel = QFrame()
        right_panel.setObjectName("rightPanel")
        right_layout = QVBoxLayout(right_panel)
        
        # Action buttons in a vertical layout
        button_layout = QVBoxLayout()
        
        # Botón Generar Plantillas
        self.btn_generar = QPushButton("Generar Reportes Insumos")
        self.btn_generar.setObjectName("btn_generar")
        self.btn_generar.setFixedHeight(40)
        button_layout.addWidget(self.btn_generar)
        
        # Nuevo botón Generar Informe Disposición Info
        self.btn_generar_informe = QPushButton("Generar Informe Disposición Informacion")
        self.btn_generar_informe.setObjectName("btn_generar_informe")
        self.btn_generar_informe.setFixedHeight(40)
        button_layout.addWidget(self.btn_generar_informe)
        
        # Layout horizontal para los botones de abrir
        open_buttons_layout = QHBoxLayout()
        
        # Botón Abrir Resultados
        self.btn_abrir = QPushButton("Abrir Resultados Insumos")
        self.btn_abrir.setObjectName("btn_abrir")
        self.btn_abrir.setFixedHeight(40)
        open_buttons_layout.addWidget(self.btn_abrir)
        
        # Nuevo botón Abrir Resultados Disposición
        self.btn_abrir_disposicion = QPushButton("Abrir Resultados Disposición")
        self.btn_abrir_disposicion.setObjectName("btn_abrir_disposicion")
        self.btn_abrir_disposicion.setFixedHeight(40)
        open_buttons_layout.addWidget(self.btn_abrir_disposicion)
        
        # Agregar el layout horizontal al layout vertical principal
        button_layout.addLayout(open_buttons_layout)
        right_layout.addLayout(button_layout)
        
        # Console
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setObjectName("console")
        right_layout.addWidget(self.console)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        right_layout.addWidget(self.progress_bar)
        
        # Add panels to tab1 layout
        tab1_layout.addWidget(left_panel)
        tab1_layout.addWidget(right_panel, 2)
        
        # Add tabs
        self.tab_widget.addTab(self.tab1, "Gestión Base Municipios")
        
        # Segunda pestaña (Autodescarga OT's)
        self.second_tab = SecondTabComponent(self)
        self.tab_widget.addTab(self.second_tab, "Autodescarga OT's")
        
        # Tercera pestaña (Visualización de Datos)
        self.visualization_tab = TablaVisualizacion(self)
        self.tab_widget.addTab(self.visualization_tab, "Visualización de Datos")
        
        # Add tab widget to main layout
        main_layout = QHBoxLayout(self.central_widget)
        main_layout.addWidget(self.tab_widget)
        
        # Connect signals
        self.btn_actualizar.clicked.connect(self.actualizar_insumos)
        self.btn_actualizar_filtros.clicked.connect(self.cargar_datos_excel)
        self.btn_generar.clicked.connect(self.generar_plantillas)
        self.btn_generar_informe.clicked.connect(self.generar_informe_disposicion)
        self.btn_abrir.clicked.connect(self.abrir_resultados)
        self.btn_abrir_disposicion.clicked.connect(self.abrir_resultados_disposicion)

    def generar_informe_disposicion(self):
        """Genera el informe de disposición ejecutando los scripts necesarios"""
        if not any(self.selected_filters.values()):
            self.log_error("No hay filtros seleccionados. Por favor, seleccione al menos un filtro.")
            return
                
        try:
            self.log_info("Iniciando generación del informe de disposición...")
            self.progress_bar.setRange(0, 0)  # Modo indeterminado
            
            # Guardar una copia de los filtros actuales
            current_filters = self.selected_filters.copy()
            self.log_info(f"Filtros actuales: {current_filters}")
            
            from pathlib import Path
            import importlib.util
            
            current_dir = Path(__file__).resolve().parent
            
            # Guardar filtros actuales
            filter_handler = FilterHandler()
            filter_handler.save_filters(current_filters)
            
            # Secuencia de scripts
            scripts_to_run = [
                ("1_Actualizar_BD_Consulta.py", "main"),
                ("5_Actualizar_Rutas_Consultas.py", "main"),
                ("6_Concatenar_DB.py", "create_new_database"),
                ("7_Script.py", "main")
            ]
            
            for script_name, function_name in scripts_to_run:
                script_path = current_dir / script_name
                
                if not script_path.exists():
                    self.log_error(f"No se encuentra el script: {script_name}")
                    continue
                    
                self.log_info(f"Ejecutando {script_name}...")
                
                try:
                    spec = importlib.util.spec_from_file_location(
                        script_name.replace(".py", ""),
                        str(script_path)
                    )
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[script_name.replace(".py", "")] = module
                    spec.loader.exec_module(module)
                    
                    if function_name == "main" and hasattr(module, 'main'):
                        module.main()
                    elif function_name == "create_new_database" and hasattr(module, 'create_new_database'):
                        module.create_new_database()
                    else:
                        raise Exception(f"No se encontró la función {function_name} en {script_name}")
                    
                    self.log_info(f"{script_name} completado correctamente")
                    
                except Exception as e:
                    self.log_error(f"Error en {script_name}: {str(e)}")
                    import traceback
                    self.log_error(traceback.format_exc())
                    return
            
            # Restaurar los filtros después de la ejecución
            self.selected_filters = current_filters
            filter_handler.save_filters(current_filters)
            self.log_info("Filtros restaurados después de la ejecución")
            
            self.log_info("Informe de disposición generado exitosamente")
            
        except Exception as e:
            self.log_error(f"Error durante la generación del informe: {str(e)}")
            import traceback
            self.log_error(traceback.format_exc())
        finally:
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)


    def apply_styles(self):
        # Color de fondo tipo desierto oscuro
        background_color = "#2D2A24"  # Beige muy oscuro, casi camuflado
        button_text_color = "#E8E6E3"  # Color claro para texto
        accent_color = "#A67C52"      # Marrón desert-camo
        button_red = "#8B0000"        # Rojo oscuro para los botones de abrir

        self.setStyleSheet(f"""
            QMainWindow {{
                background-color: {background_color};
            }}
            
            #leftPanel {{
                background-color: rgba(45, 42, 36, 0.95);
                border: 1px solid rgba(166, 124, 82, 0.3);
                border-radius: 8px;
                max-width: 350px;
                margin: 10px;
                padding: 10px;
            }}
            
            #rightPanel {{
                background-color: rgba(45, 42, 36, 0.95);
                border: 1px solid rgba(166, 124, 82, 0.3);
                border-radius: 8px;
                margin: 10px;
                padding: 10px;
            }}
            
            #sectionTitle {{
                font-size: 16px;
                font-weight: bold;
                color: {button_text_color};
                padding: 10px 0;
                text-align: center;
            }}
            
            /* Botón Actualizar Base Municipios */
            #updateButton {{
                background-color: #8B0000;
                color: {button_text_color};
                border: none;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 11px;
                margin-bottom: 5px;
                font-weight: bold;
                text-align: center;
            }}
            #updateButton:hover {{
                background-color: #A00000;
            }}
            
            /* Botón Actualizar Filtros */
            #refreshButton {{
                background-color: #2E7D32;
                color: {button_text_color};
                border: none;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 11px;
                font-weight: bold;
                text-align: center;
            }}
            #refreshButton:hover {{
                background-color: #388E3C;
            }}
            
            /* Botones de filtro */
            QPushButton[objectName^="filterButton"] {{
                background-color: rgba(166, 124, 82, 0.1);
                color: {button_text_color};
                border: 1px solid {accent_color};
                text-align: center;
                padding: 10px;
                font-weight: normal;
                margin: 5px 0;
                border-radius: 6px;
            }}
            QPushButton[objectName^="filterButton"]:hover {{
                background-color: rgba(166, 124, 82, 0.2);
            }}
            
            /* Botones de generación (color marrón) */
            #btn_generar, #btn_generar_informe {{
                background-color: {accent_color};
                color: {button_text_color};
                border: none;
                border-radius: 6px;
                padding: 8px 15px;
                font-size: 14px;
                font-weight: bold;
                margin: 5px;
                text-align: center;
            }}
            #btn_generar:hover, #btn_generar_informe:hover {{
                background-color: #B68C62;
            }}
            
            /* Botones de abrir (color rojo) */
            #btn_abrir, #btn_abrir_disposicion {{
                background-color: {button_red};
                color: {button_text_color};
                border: none;
                border-radius: 6px;
                padding: 8px 15px;
                font-size: 14px;
                font-weight: bold;
                margin: 5px;
                text-align: center;
            }}
            #btn_abrir:hover, #btn_abrir_disposicion:hover {{
                background-color: #A00000;
            }}
            
            /* Consola */
            #console {{
                background-color: #1E1E1E;
                color: #00FF00;
                font-family: 'Consolas', monospace;
                border-radius: 6px;
                padding: 15px;
                margin: 10px 0;
                border: 1px solid rgba(166, 124, 82, 0.2);
            }}
            
            /* Barra de progreso */
            QProgressBar {{
                border: 1px solid {accent_color};
                border-radius: 4px;
                text-align: center;
                margin: 10px 0;
                background-color: rgba(45, 42, 36, 0.95);
            }}
            QProgressBar::chunk {{
                background-color: {accent_color};
                border-radius: 3px;
            }}
            
            /* Tabs */
            QTabWidget::pane {{
                border: 1px solid {accent_color};
                border-radius: 6px;
                background-color: {background_color};
            }}
            
            QTabBar::tab {{
                background-color: rgba(166, 124, 82, 0.1);
                color: {button_text_color};
                padding: 8px 15px;
                margin: 2px;
                border-radius: 4px 4px 0 0;
            }}
            QTabBar::tab:selected {{
                background-color: {accent_color};
            }}
        """)

class TablaVisualizacion(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Botones superiores
        button_layout = QHBoxLayout()
        
        # Botón de refrescar
        self.refresh_btn = QPushButton("Refrescar Estado de Consultas")
        self.refresh_btn.setObjectName("refreshButton")
        self.refresh_btn.clicked.connect(self.load_data)
        button_layout.addWidget(self.refresh_btn)
        
        # Botón existente de limpiar
        self.clear_db_btn = QPushButton("Limpiar Base de Datos")
        self.clear_db_btn.setObjectName("clearDbButton")
        self.clear_db_btn.clicked.connect(self.clear_database)
        button_layout.addWidget(self.clear_db_btn)
        
        layout.addLayout(button_layout)
        
        # Layout para las tablas
        self.table_layout = QHBoxLayout()
        
        # Crear las tablas
        self.pending_table = QTableWidget()
        self.deleted_table = QTableWidget()
        
        # Configurar las tablas
        self.setup_table(self.pending_table, "Descargas Pendientes", QColor(0, 200, 0))
        self.setup_table(self.deleted_table, "Descargas Finalizadas", QColor(200, 0, 0))
        
        self.table_layout.addWidget(self.pending_table)
        self.table_layout.addWidget(self.deleted_table)
        layout.addLayout(self.table_layout)
        
        # Aplicar estilos
        self.setStyleSheet("""
            QTableWidget {
                background-color: #2D2D2D;
                color: #FFFFFF;
                gridline-color: #3A3A3A;
            }
            QHeaderView::section {
                background-color: #1a237e;
                color: #FFFFFF;
                padding: 5px;
                border: 1px solid #3A3A3A;
            }
            QTableWidget::item {
                border: 1px solid #3A3A3A;
            }
            #refreshButton {
                background-color: #2E7D32;
                color: white;
                padding: 8px 15px;
                border: none;
                border-radius: 4px;
                margin: 5px;
            }
            #refreshButton:hover {
                background-color: #388E3C;
            }
            #clearDbButton {
                background-color: #6B0000;
                color: white;
                padding: 8px 15px;
                border: none;
                border-radius: 4px;
                margin: 5px;
            }
            #clearDbButton:hover {
                background-color: #8B0000;
            }
        """)
        
        # Cargar datos iniciales
        self.load_data()

    def setup_table(self, table, title, color):
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Municipio", "Objetivo Descargas", "Total Descargados"])
        table.setStyleSheet(f"""
            QHeaderView::section {{
                background-color: {color.name()};
            }}
        """)
        table.setHorizontalHeaderItem(0, QTableWidgetItem(title))
        table.horizontalHeader().setStretchLastSection(True)
        table.verticalHeader().setVisible(False)

    def get_db_path(self):
        script_dir = Path(__file__).parent
        db_path = os.path.join(script_dir.parent.parent,"src","COLOMBIA_OT_AUTODESCARGA", "db", "Consultas.db")
        if not os.path.exists(db_path):
            raise FileNotFoundError(f"No se encontró la base de datos en {db_path}")
        return db_path

    def load_data(self):
        try:
            db_path = self.get_db_path()
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            # Cargar datos pendientes
            cursor.execute("SELECT municipio, objetivo_descargas, total_descargados FROM municipios_tab_replica")
            self.populate_table(self.pending_table, cursor.fetchall())

            # Cargar datos finalizados
            cursor.execute("SELECT municipio, objetivo_descargas, total_descargados FROM municipios_tab_borrados")
            self.populate_table(self.deleted_table, cursor.fetchall())

            conn.close()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error al cargar datos: {str(e)}")

    def populate_table(self, table, data):
        table.setRowCount(len(data))
        for row, record in enumerate(data):
            for col, value in enumerate(record):
                item = QTableWidgetItem(str(value))
                table.setItem(row, col, item)

    def clear_database(self):
        reply = QMessageBox.warning(
            self,
            "Advertencia",
            "¿Está seguro de que desea eliminar toda la información de las bases de datos?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            try:
                db_path = self.get_db_path()
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()

                cursor.execute("DELETE FROM municipios_tab_replica")
                cursor.execute("DELETE FROM municipios_tab_borrados")
                conn.commit()
                conn.close()

                QMessageBox.information(self, "Éxito", "Las bases de datos han sido limpiadas exitosamente.")
                self.load_data()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Error al limpiar las tablas: {str(e)}")


class FilterDialog(QDialog):
    filterSelected = Signal(str, list)

    def __init__(self, title, items, current_selections=None, value_mapping=None, parent=None):
        super().__init__(parent)
        # Asegurarse de que el diálogo tenga el estilo correcto
        background_color = "#2D2A24"
        button_text_color = "#E8E6E3"
        accent_color = "#A67C52"

        self.value_mapping = value_mapping  # Guardar el mapeo de valores

        self.setStyleSheet(f"""
            QDialog {{
                background-color: {background_color};
                border: 1px solid {accent_color};
            }}
            QLabel {{
                color: {button_text_color};
                font-size: 12px;
            }}
            QLineEdit {{
                background-color: #1E1E1E;
                color: {button_text_color};
                border: 1px solid {accent_color};
                border-radius: 4px;
                padding: 8px;
                selection-background-color: {accent_color};
            }}
            QListWidget {{
                background-color: #1E1E1E;
                color: {button_text_color};
                border: 1px solid {accent_color};
                border-radius: 4px;
                outline: none;
            }}
            QListWidget::item {{
                padding: 8px;
                border-radius: 4px;
                color: {button_text_color};
            }}
            QListWidget::item:selected {{
                background-color: {accent_color};
                color: {button_text_color};
            }}
            QListWidget::item:hover:!selected {{
                background-color: rgba(166, 124, 82, 0.3);
            }}
            QPushButton {{
                background-color: rgba(166, 124, 82, 0.2);
                color: {button_text_color};
                border: 1px solid {accent_color};
                padding: 8px 15px;
                border-radius: 4px;
                min-width: 100px;
            }}
            QPushButton:hover {{
                background-color: rgba(166, 124, 82, 0.4);
            }}
        """)
        
        self.setWindowTitle(title)
        self.setMinimumWidth(400)
        self.setMinimumHeight(500)
        
        # Crear el layout principal
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Crear widgets
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Buscar...")
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QListWidget.ExtendedSelection)
        
        # Crear botones
        button_layout = QHBoxLayout()
        self.select_all_btn = QPushButton("Seleccionar Todo")
        self.clear_btn = QPushButton("Limpiar")
        button_layout.addWidget(self.select_all_btn)
        button_layout.addWidget(self.clear_btn)
        
        # Label de conteo
        self.count_label = QLabel("0 elementos seleccionados")
        
        # Botones de acción
        action_layout = QHBoxLayout()
        self.accept_btn = QPushButton("Aceptar")
        self.cancel_btn = QPushButton("Cancelar")
        action_layout.addWidget(self.accept_btn)
        action_layout.addWidget(self.cancel_btn)
        
        # Conectar señales
        self.search_box.textChanged.connect(self._filter_items)
        self.select_all_btn.clicked.connect(self._select_all)
        self.clear_btn.clicked.connect(self._clear_selection)
        self.accept_btn.clicked.connect(self.accept)
        self.cancel_btn.clicked.connect(self.reject)
        self.list_widget.itemSelectionChanged.connect(self._update_count)
        
        # Agregar widgets al layout
        layout.addWidget(self.search_box)
        layout.addWidget(self.list_widget)
        layout.addLayout(button_layout)
        layout.addWidget(self.count_label)
        layout.addLayout(action_layout)
        
        # Poblar la lista
        self.populate_items(items, current_selections)

    def _filter_items(self, text):
        search_text = text.lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item.setHidden(search_text not in item.text().lower())

    def _select_all(self):
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if not item.isHidden():
                item.setSelected(True)
        self._update_count()

    def _clear_selection(self):
        self.list_widget.clearSelection()
        self._update_count()

    def _update_count(self):
        count = len(self.list_widget.selectedItems())
        self.count_label.setText(f"{count} elementos seleccionados")

    def populate_items(self, items, current_selections=None):
        self.list_widget.clear()
        for item in sorted(items):
            if item is not None and str(item).strip():
                list_item = QListWidgetItem(str(item))
                self.list_widget.addItem(list_item)
                if current_selections and str(item) in current_selections:
                    list_item.setSelected(True)
        self._update_count()

    def get_selected_items(self):
        """Obtiene los items seleccionados, aplicando el mapeo si existe"""
        selected = [item.text() for item in self.list_widget.selectedItems()]
        if self.value_mapping:
            # Intentar convertir usando el mapeo, si falla devolver el valor original
            return [self.value_mapping.get(item, item) for item in selected]
        return selected


if __name__ == '__main__':
    try:
        app = QApplication(sys.argv)
        
        # Configurar fuente predeterminada
        font = app.font()
        font.setPointSize(9)
        app.setFont(font)
        
        window = MainWindow()
        window.show()
        
        sys.exit(app.exec())
        
    except Exception as e:
        print(f"Error fatal: {str(e)}")
        sys.exit(1)
