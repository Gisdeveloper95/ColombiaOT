import sqlite3
import os
from pathlib import Path

def get_db_path(db_name):
    current_path = Path(__file__).parent
    db_path = current_path.parent / 'db' / db_name
    return str(db_path)

def create_new_database():
    try:
        # Path para la nueva base de datos
        new_db_path = get_db_path('registros_totales_post.db')
        municipios_path = get_db_path('municipios.db')
        rutas_path = get_db_path('rutas2.db')
        
        print(f"Verificando bases de datos:")
        print(f"- municipios.db: {os.path.exists(municipios_path)}")
        print(f"- rutas2.db: {os.path.exists(rutas_path)}")
        
        # Verificar contenido de las bases
        conn_municipios = sqlite3.connect(municipios_path)
        cursor = conn_municipios.cursor()
        cursor.execute("SELECT COUNT(*) FROM municipios")
        count_municipios = cursor.fetchone()[0]
        print(f"Registros en municipios.db: {count_municipios}")
        
        # Obtener estructura de municipios
        cursor.execute("PRAGMA table_info(municipios)")
        columns_info = cursor.fetchall()
        print("Estructura de municipios.db:")
        for col in columns_info:
            print(f"- {col[1]} ({col[2]})")
        conn_municipios.close()
        
        conn_rutas = sqlite3.connect(rutas_path)
        cursor = conn_rutas.cursor()
        cursor.execute("SELECT COUNT(*) FROM rutas")
        count_rutas = cursor.fetchone()[0]
        print(f"Registros en rutas2.db: {count_rutas}")
        conn_rutas.close()
        
        if count_municipios == 0:
            raise Exception("La base de datos municipios.db está vacía")
        
        if count_rutas == 0:
            raise Exception("La base de datos rutas2.db está vacía")
        
        # Borrar la base de datos destino si existe
        if os.path.exists(new_db_path):
            os.remove(new_db_path)
            print(f"Base de datos anterior eliminada: {new_db_path}")
        
        # Conectar a las bases de datos
        nueva_db = sqlite3.connect(new_db_path)
        municipios_db = sqlite3.connect(municipios_path)
        rutas_db = sqlite3.connect(rutas_path)
        
        print("Bases de datos conectadas correctamente")
        
        # Crear cursores
        cursor_nuevo = nueva_db.cursor()
        cursor_municipios = municipios_db.cursor()
        cursor_rutas = rutas_db.cursor()
        
        # Obtener estructura y datos de la tabla municipios
        cursor_municipios.execute("SELECT * FROM municipios")
        municipios_data = cursor_municipios.fetchall()
        
        # Obtener nombres de columnas de municipios
        cursor_municipios.execute("PRAGMA table_info(municipios)")
        columns_info = cursor_municipios.fetchall()
        columns = [column[1] for column in columns_info]
        
        print("Columnas de municipios:", columns)
        
        # Crear la nueva tabla con la columna adicional
        create_columns = [f'"{col[1]}" {col[2]}' for col in columns_info]
        create_columns.append('"ruta_completa" TEXT')
        create_sql = f'CREATE TABLE municipios ({", ".join(create_columns)})'
        cursor_nuevo.execute(create_sql)
        
        print("Tabla creada correctamente")
        
        # Obtener datos de rutas
        cursor_rutas.execute("SELECT codigo_mpio_rutas, ruta_completa FROM rutas")
        rutas_data = cursor_rutas.fetchall()
        
        # Crear un diccionario donde la clave es codigo_mpio_rutas y el valor es una lista de rutas_completas
        rutas_dict = {}
        for codigo, ruta in rutas_data:
            if codigo not in rutas_dict:
                rutas_dict[codigo] = []
            rutas_dict[codigo].append(ruta)
        
        print(f"Procesando {len(municipios_data)} municipios...")
        print(f"Rutas disponibles para {len(rutas_dict)} municipios")
        
        # Mostrar algunos ejemplos de códigos y rutas
        print("\nEjemplos de rutas disponibles:")
        count = 0
        for codigo in list(rutas_dict.keys())[:3]:
            print(f"Código {codigo}: {len(rutas_dict[codigo])} rutas")
            count += 1
            if count >= 3:
                break
        
        # Preparar la inserción de datos
        columns_str = ", ".join(f'"{col}"' for col in columns)
        placeholders = ", ".join(["?" for _ in columns])
        insert_sql = f'INSERT INTO municipios ({columns_str}, ruta_completa) VALUES ({placeholders}, ?)'
        
        # Contador para nuevos registros
        new_records = 0
        matched_records = 0
        
        # Para cada municipio
        for municipio in municipios_data:
            codigo_mpio = None
            # Encontrar el índice de la columna codigo_mpio
            for i, col in enumerate(columns):
                if col.lower() == 'codigo_mpio':
                    codigo_mpio = municipio[i]
                    break
            
            if codigo_mpio in rutas_dict:
                matched_records += 1
                # Si hay rutas para este municipio, crear un registro por cada ruta
                for ruta in rutas_dict[codigo_mpio]:
                    new_record = list(municipio) + [ruta]
                    cursor_nuevo.execute(insert_sql, new_record)
                    new_records += 1
            else:
                # Si no hay rutas, insertar el registro con ruta_completa NULL
                new_record = list(municipio) + [None]
                cursor_nuevo.execute(insert_sql, new_record)
                new_records += 1
        
        nueva_db.commit()
        
        print(f"\nResumen del proceso:")
        print(f"- Municipios procesados: {len(municipios_data)}")
        print(f"- Municipios con rutas: {matched_records}")
        print(f"- Total registros creados: {new_records}")
        print(f"Base de datos creada exitosamente en: {new_db_path}")
        
    except sqlite3.Error as e:
        print(f"Error en SQLite: {e}")
        raise
    except Exception as e:
        print(f"Error: {e}")
        raise
    finally:
        # Cerrar conexiones
        locals_dict = locals()
        for conn_name in ['nueva_db', 'municipios_db', 'rutas_db']:
            if conn_name in locals_dict and locals_dict[conn_name]:
                try:
                    locals_dict[conn_name].close()
                except Exception as e:
                    print(f"Error cerrando conexión {conn_name}: {e}")

if __name__ == "__main__":
    try:
        create_new_database()
    except Exception as e:
        print(f"Error en el proceso principal: {e}")

