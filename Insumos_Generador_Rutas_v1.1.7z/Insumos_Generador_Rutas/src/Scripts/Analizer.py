import os
import sys
from pathlib import Path



import os
from pathlib import Path
import sys
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
import tkinter as tk
from tkinter import ttk
import threading
from datetime import datetime
import zipfile
import shutil
import subprocess

class CountdownFrame(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        
        self.countdown_frame = ttk.Frame(self)
        self.countdown_frame.pack(pady=5)
        
        self.message_label = ttk.Label(
            self.countdown_frame,
            text="Matriz Actualizada, Cerrando en:",
            font=('Helvetica', 10)
        )
        self.message_label.pack()
        
        self.counter_label = ttk.Label(
            self.countdown_frame,
            text="10",
            font=('Helvetica', 24, 'bold')
        )
        self.counter_label.pack()
        
        self.progress_label = ttk.Label(
            self.countdown_frame,
            text="⚪" * 10,
            font=('Helvetica', 10)
        )
        self.progress_label.pack()
        
        self.remaining = 10
        self.is_running = False
        
        self.pack_forget()
    
    def start(self, callback):
        self.pack(fill=tk.X, pady=10)
        self.is_running = True
        self.callback = callback
        self.update_countdown()
    
    def update_countdown(self):
        if not self.is_running:
            return
            
        if self.remaining > 0:
            self.counter_label.config(text=str(self.remaining))
            filled = "⚫" * (10 - self.remaining)
            empty = "⚪" * self.remaining
            self.progress_label.config(text=filled + empty)
            self.remaining -= 1
            self.after(1000, self.update_countdown)
        else:
            self.callback()
    
    def stop(self):
        self.is_running = False

class DownloadProgressGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Descarga de Matriz Municipal")
        self.root.geometry("750x650")
        self.root.configure(bg='#f0f0f0')
        
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - 750) // 2
        y = (screen_height - 650) // 2
        self.root.geometry(f"750x650+{x}+{y}")
        
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        title_label = ttk.Label(
            main_frame, 
            text="Descarga de Matriz Municipal", 
            font=('Helvetica', 16, 'bold')
        )
        title_label.pack(pady=10)
        
        self.status_frame = ttk.LabelFrame(main_frame, text="Estado Actual", padding="10")
        self.status_frame.pack(fill=tk.X, pady=10)
        
        self.status_label = ttk.Label(
            self.status_frame, 
            text="Iniciando proceso...", 
            font=('Helvetica', 10)
        )
        self.status_label.pack(fill=tk.X)
        
        self.progress = ttk.Progressbar(
            main_frame, 
            orient="horizontal", 
            length=500, 
            mode="determinate"
        )
        self.progress.pack(pady=20)
        
        log_frame = ttk.LabelFrame(main_frame, text="Registro detallado de actividad", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(
            log_frame, 
            height=15,
            width=70, 
            font=('Consolas', 9),
            bg='white',
            wrap=tk.WORD
        )
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        
        self.countdown = CountdownFrame(main_frame)
        
        self.close_button = ttk.Button(
            main_frame, 
            text="Cerrar ahora", 
            command=self.root.destroy,
            state='disabled'
        )
        self.close_button.pack(pady=10)
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.can_close = False
        
        self.original_stdout = sys.stdout
        sys.stdout = self
    
    def write(self, text):
        self.original_stdout.write(text)
        self.add_log(text.strip())
    
    def flush(self):
        self.original_stdout.flush()
    
    def __del__(self):
        if hasattr(self, 'original_stdout'):
            sys.stdout = self.original_stdout
    
    def update_status(self, status, progress_value=None):
        print(f"Estado: {status}")
        self.status_label.config(text=status)
        if progress_value is not None:
            self.progress['value'] = progress_value
        self.root.update()
    
    def add_log(self, message):
        if message.strip():
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
            self.log_text.see(tk.END)
            self.root.update()
    
    def on_closing(self):
        if self.can_close:
            if hasattr(self, 'original_stdout'):
                sys.stdout = self.original_stdout
            self.countdown.stop()
            self.root.destroy()
    
    def enable_close(self):
        self.can_close = True
        self.close_button.config(state='normal')
        self.countdown.start(self.root.destroy)

class SharePointDownloader:
    def __init__(self, gui):
        self.gui = gui
        self.script_path = Path(os.path.abspath(__file__))
        self.project_root = self.find_project_root()
        self.target_dir = self.project_root / "plantilla_actual"
        self.temp_dir = self.script_path.parent / "temp"
        
        firefox_path = self.find_firefox()
        
        # Configuración mejorada de Firefox
        self.firefox_options = Options()
        self.firefox_options.binary_location = firefox_path
        self.firefox_options.add_argument("--headless")
        
        # Configuraciones críticas para SharePoint/Office365
        self.firefox_options.set_preference("network.automatic-ntlm-auth.trusted-uris", "sharepoint.com,microsoftonline.com")
        self.firefox_options.set_preference("network.negotiate-auth.trusted-uris", "sharepoint.com,microsoftonline.com")
        self.firefox_options.set_preference("network.auth.use-sspi", True)
        self.firefox_options.set_preference("security.enterprise_roots.enabled", True)
        
        # Configuración de cookies y caché
        self.firefox_options.set_preference("network.cookie.cookieBehavior", 0)
        self.firefox_options.set_preference("network.cookie.lifetimePolicy", 0)
        self.firefox_options.set_preference("browser.cache.disk.enable", True)
        self.firefox_options.set_preference("browser.cache.memory.enable", True)
        
        # Configuración de descarga
        self.firefox_options.set_preference("browser.download.folderList", 2)
        self.firefox_options.set_preference("browser.download.dir", str(self.temp_dir))
        self.firefox_options.set_preference("browser.download.useDownloadDir", True)
        self.firefox_options.set_preference("browser.download.manager.showWhenStarting", False)
        self.firefox_options.set_preference("browser.helperApps.neverAsk.saveToDisk", 
            "application/zip,application/octet-stream,application/x-zip-compressed")
        
    def find_firefox(self):
        """Busca Firefox en todas las ubicaciones posibles incluyendo Microsoft Store"""
        try:
            # Primera prioridad: Microsoft Store - búsqueda dinámica
            windowsapps = Path(r'C:\Program Files\WindowsApps')
            if windowsapps.exists():
                # Buscar todas las carpetas de Firefox
                firefox_folders = sorted(windowsapps.glob('Mozilla.Firefox*'), reverse=True)
                for folder in firefox_folders:
                    possible_paths = [
                        folder / 'VFS' / 'ProgramFiles' / 'Firefox Package Root' / 'firefox.exe',
                        folder / 'firefox.exe'
                    ]
                    for path in possible_paths:
                        if path.is_file():
                            print(f"Firefox encontrado en Microsoft Store: {path}")
                            return str(path)

            # Segunda prioridad: Instalación tradicional
            traditional_paths = [
                r'C:\Program Files\Mozilla Firefox\firefox.exe',
                r'C:\Program Files (x86)\Mozilla Firefox\firefox.exe',
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Mozilla Firefox', 'firefox.exe'),
                os.path.join(os.environ.get('PROGRAMFILES', ''), 'Mozilla Firefox', 'firefox.exe'),
                os.path.join(os.environ.get('PROGRAMFILES(X86)', ''), 'Mozilla Firefox', 'firefox.exe')
            ]
            
            for path in traditional_paths:
                if os.path.isfile(path):
                    print(f"Firefox encontrado en instalación tradicional: {path}")
                    return path
                    
            # Tercer intento: Buscar en el PATH del sistema
            try:
                result = subprocess.run(['where', 'firefox.exe'], 
                                    capture_output=True, 
                                    text=True, 
                                    check=True)
                if result.stdout.strip():
                    path = result.stdout.splitlines()[0]
                    print(f"Firefox encontrado en PATH: {path}")
                    return path
            except:
                pass

            # Si llegamos aquí, no se encontró Firefox
            all_locations = "\n- ".join([str(p) for p in traditional_paths])
            raise Exception(
                "No se pudo encontrar Firefox. Se buscó en:\n"
                f"- Microsoft Store (WindowsApps)\n- {all_locations}\n"
                "Por favor, asegúrese de que Firefox está instalado."
            )
                
        except Exception as e:
            print(f"Error buscando Firefox: {str(e)}")
            raise Exception(f"No se pudo encontrar Firefox en ninguna ubicación común: {str(e)}")
    def find_project_root(self):
        try:
            src_dir = self.script_path.parent.parent
            if not src_dir.name == "src":
                raise Exception("La estructura del proyecto no es la esperada (src/Scripts)")
            plantilla_dir = src_dir / "plantilla_actual"
            plantilla_dir.mkdir(parents=True, exist_ok=True)
            return src_dir
        except Exception as e:
            raise Exception(f"Error al determinar la estructura del proyecto: {str(e)}")

    def clean_directories(self):
        print("Iniciando limpieza de directorios...")
        for directory in [self.temp_dir, self.target_dir]:
            try:
                if directory.exists():
                    shutil.rmtree(directory)
                directory.mkdir(parents=True, exist_ok=True)
                print(f"Directorio limpiado y creado: {directory}")
            except Exception as e:
                print(f"Error al limpiar directorio {directory}: {str(e)}")

    def wait_for_zip_download(self, timeout=60):
        print("Esperando descarga del archivo ZIP...")
        start_time = time.time()
        zip_file = None
        last_size = 0
        size_stable_count = 0
        
        while time.time() - start_time < timeout:
            zip_files = list(self.temp_dir.glob("*.zip"))
            partial_files = list(self.temp_dir.glob("*.part")) + list(self.temp_dir.glob("*.tmp"))
            
            if partial_files:
                print("Archivo aún descargándose...")
                progress = min(((time.time() - start_time) / timeout) * 100, 99)
                self.gui.update_status("Descargando archivo ZIP...", progress)
                time.sleep(1)
                continue
                
            if zip_files:
                zip_file = zip_files[0]
                current_size = zip_file.stat().st_size
                
                if current_size == last_size:
                    size_stable_count += 1
                    print(f"Verificando completitud del archivo... ({size_stable_count}/3)")
                    if size_stable_count >= 3:
                        return zip_file
                else:
                    size_stable_count = 0
                    print(f"Tamaño actual: {current_size / 1024 / 1024:.2f} MB")
                
                last_size = current_size
            
            time.sleep(1)
            progress = min(((time.time() - start_time) / timeout) * 100, 99)
            self.gui.update_status("Verificando descarga...", progress)
        
        return None

    def extract_and_move_files(self, zip_path):
        print(f"Procesando archivo ZIP: {zip_path}")
        time.sleep(1)
        
        try:
            if not zip_path.exists():
                raise Exception(f"El archivo ZIP no existe: {zip_path}")
            
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)

            excel_files = []
            for root, dirs, files in os.walk(self.temp_dir):
                for file in files:
                    if file.endswith('.xlsx'):
                        excel_files.append(Path(root) / file)

            if not excel_files:
                raise Exception("No se encontraron archivos Excel en el ZIP")

            for excel_file in excel_files:
                dest_file = self.target_dir / excel_file.name
                shutil.copy2(excel_file, dest_file)
                print(f"Archivo copiado: {excel_file.name}")

            return excel_files

        except Exception as e:
            print(f"Error procesando ZIP: {str(e)}")
            raise


    def check_network_status(self):
        """Verifica el estado de la red y la conexión a SharePoint"""
        import socket
        import requests
        
        print("\n=== Diagnóstico de Red ===")
        
        try:
            # Verificar resolución DNS
            sharepoint_ip = socket.gethostbyname('sharepoint.com')
            print(f"✓ DNS SharePoint: {sharepoint_ip}")
            
            # Verificar proxy del sistema
            proxy = os.environ.get('HTTP_PROXY') or os.environ.get('HTTPS_PROXY')
            print(f"Proxy del sistema: {proxy if proxy else 'No configurado'}")
            
            # Verificar conectividad básica
            response = requests.get('https://sharepoint.com', timeout=10)
            print(f"✓ Conexión SharePoint: {response.status_code}")
            
            # Verificar permisos de escritura
            test_file = self.temp_dir / "test.txt"
            test_file.write_text("test")
            test_file.unlink()
            print("✓ Permisos de escritura OK")
            
        except Exception as e:
            print(f"Error en diagnóstico: {str(e)}")
        
        print("========================\n")

    def download_from_sharepoint(self, url):
        try:
            print(f"Iniciando descarga desde: {url}")
            self.gui.update_status("Iniciando proceso...", 0)
            
            # Verificar y preparar directorios
            self.clean_directories()
            self.gui.update_status("Directorios preparados", 10)
            
            # Configuración del driver
            from selenium.webdriver.firefox.service import Service
            service = Service(log_path=os.devnull)
            driver = webdriver.Firefox(options=self.firefox_options, service=service)
            driver.set_page_load_timeout(60)  # 60 segundos de timeout
            
            try:
                print("Accediendo a SharePoint...")
                self.gui.update_status("Accediendo a SharePoint...", 20)
                
                # Cargar la página con reintentos
                max_retries = 3
                for retry in range(max_retries):
                    try:
                        driver.get(url)
                        # Esperar a que la página cargue completamente
                        WebDriverWait(driver, 30).until(
                            lambda d: d.execute_script('return document.readyState') == 'complete'
                        )
                        break
                    except Exception as e:
                        if retry == max_retries - 1:
                            raise Exception(f"No se pudo cargar la página después de {max_retries} intentos: {str(e)}")
                        print(f"Reintento {retry + 1}/{max_retries}...")
                        time.sleep(5)

                print(f"Título de la página: {driver.title}")
                self.gui.update_status("Accediendo a SharePoint...", 30)
                time.sleep(5)  # Espera adicional para carga completa

                print("Buscando botón de descarga...")
                button_found = False
                button_selectors = [
                    "//button[@name='Descargar']",
                    "//button[contains(@class, 'download')]",
                    "//button[contains(text(), 'Descargar')]",
                    "//button[contains(@aria-label, 'Descargar')]"
                ]
                
                for selector in button_selectors:
                    try:
                        download_button = WebDriverWait(driver, 10).until(
                            EC.presence_of_element_located((By.XPATH, selector))
                        )
                        if download_button.is_displayed() and download_button.is_enabled():
                            button_found = True
                            break
                    except:
                        continue

                if not button_found:
                    raise Exception("No se pudo encontrar el botón de descarga")

                # Intentar diferentes métodos de clic
                click_methods = [
                    lambda: download_button.click(),
                    lambda: driver.execute_script("arguments[0].click();", download_button),
                    lambda: ActionChains(driver).move_to_element(download_button).click().perform()
                ]

                click_success = False
                for click_method in click_methods:
                    try:
                        click_method()
                        click_success = True
                        break
                    except:
                        continue

                if not click_success:
                    raise Exception("No se pudo hacer clic en el botón de descarga")

                print("Haciendo clic en el botón de descarga...")
                self.gui.update_status("Esperando descarga del archivo...", 40)
                
                # Esperar la descarga del archivo
                zip_file = self.wait_for_zip_download(timeout=120)
                if not zip_file:
                    raise Exception("Tiempo de espera agotado para la descarga del ZIP")

                # Procesar el archivo ZIP
                self.gui.update_status("Procesando archivo ZIP...", 80)
                excel_files = self.extract_and_move_files(zip_file)

                # Completado exitosamente
                self.gui.update_status("¡Proceso completado con éxito!", 100)
                self.gui.add_log("-" * 50)
                self.gui.add_log("Proceso completado:")
                for excel_file in excel_files:
                    size_mb = excel_file.stat().st_size / (1024 * 1024)
                    self.gui.add_log(f"Archivo: {excel_file.name}")
                    self.gui.add_log(f"Tamaño: {size_mb:.2f} MB")
                self.gui.add_log("-" * 50)

            except Exception as e:
                print(f"Error durante la navegación: {str(e)}")
                # Capturar screenshot en caso de error
                try:
                    screenshot_path = self.temp_dir / "error_screenshot.png"
                    driver.save_screenshot(str(screenshot_path))
                    print(f"Screenshot guardado en: {screenshot_path}")
                except:
                    pass
                raise

            finally:
                print("Cerrando navegador...")
                try:
                    driver.quit()
                except:
                    print("Error al cerrar el navegador")
                
                try:
                    if self.temp_dir.exists():
                        shutil.rmtree(self.temp_dir)
                        print("Directorio temporal eliminado")
                except:
                    print("Error al eliminar directorio temporal")

        except Exception as e:
            error_msg = f"ERROR: {str(e)}"
            print(error_msg)
            self.gui.update_status(f"Error: {str(e)}", 0)
            self.gui.add_log(f"Error fatal: {str(e)}")
            raise
            
        finally:
            self.gui.enable_close()

def verify_and_clean_directories():
    """Verificación inicial y limpieza de directorios"""
    try:
        # Obtener la ruta del script actual
        script_path = Path(os.path.abspath(__file__))
        
        # Determinar las rutas relativas desde el script
        src_dir = script_path.parent.parent  # Subir un nivel desde Scripts
        temp_dir = script_path.parent / "temp"  # temp estará junto al script
        target_dir = src_dir / "plantilla_actual"
        
        print("Verificando y limpiando directorios existentes...")
        
        # Verificar que estamos en la estructura correcta
        if not src_dir.name == "src":
            raise Exception("La estructura del proyecto no es la esperada (src/Scripts)")
        
        # Limpiar directorio temporal si existe
        if temp_dir.exists():
            print(f"Encontrado directorio temporal antiguo: {temp_dir}")
            try:
                shutil.rmtree(temp_dir)
                print("Directorio temporal antiguo eliminado exitosamente")
            except Exception as e:
                print(f"Error al eliminar directorio temporal: {e}")
                
        # Limpiar directorio destino si existe
        if target_dir.exists():
            print(f"Encontrado directorio destino antiguo: {target_dir}")
            try:
                shutil.rmtree(target_dir)
                print("Directorio destino antiguo eliminado exitosamente")
            except Exception as e:
                print(f"Error al eliminar directorio destino: {e}")
                
        print("Verificación inicial completada")
        
    except Exception as e:
        print(f"Error en la verificación inicial: {e}")
        raise

def setup_tcl():
    """Configura el entorno TCL/TK específicamente para entornos virtuales"""
    import sys
    import os
    from pathlib import Path
    
    def is_venv():
        return (hasattr(sys, 'real_prefix') or
                (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))
    
    if not is_venv():
        return True  # No necesitamos hacer nada si no es un entorno virtual
        
    try:
        # Obtener la ruta base de Python (no la del venv)
        base_python = sys.base_prefix
        
        # Rutas comunes donde Python base almacena TCL
        possible_tcl_locations = [
            os.path.join(base_python, 'tcl', 'tcl8.6'),
            os.path.join(base_python, 'Lib', 'tcl8.6'),
            os.path.join(base_python, 'Lib', 'tcl'),
            r'C:\Program Files\Python311\tcl\tcl8.6',
            r'C:\Program Files\Python312\tcl\tcl8.6',
            r'C:\Program Files\Python313\tcl\tcl8.6',
        ]
        
        # Buscar TCL en la instalación base de Python
        tcl_path = None
        for loc in possible_tcl_locations:
            if os.path.exists(loc) and os.path.exists(os.path.join(loc, 'init.tcl')):
                tcl_path = loc
                break
                
        if not tcl_path:
            raise Exception("No se encontró TCL en la instalación base de Python")
            
        # Configurar variables de entorno para TCL y TK
        os.environ['TCL_LIBRARY'] = tcl_path
        os.environ['TK_LIBRARY'] = tcl_path.replace('tcl8', 'tk8')
        
        print(f"TCL configurado desde Python base: {tcl_path}")
        return True
        
    except Exception as e:
        print(f"Error configurando TCL: {str(e)}")
        print("\nInformación de diagnóstico:")
        print(f"Python executable: {sys.executable}")
        print(f"Python prefix: {sys.prefix}")
        print(f"Python base prefix: {sys.base_prefix}")
        print(f"Es entorno virtual: {is_venv()}")
        return False

# Modificar el inicio del main() para usar esta configuración
def main():
    try:
        # Configurar TCL antes de importar tkinter
        if not setup_tcl():
            print("\nError: No se pudo configurar TCL/TK.")
            print("Por favor, ejecute: pip install tk")
            sys.exit(1)
            
        # Ahora es seguro importar tkinter y otros módulos que lo usen
        import tkinter as tk
        from tkinter import ttk
        
        # Resto del código...
        verify_and_clean_directories()
        
        def start_download():
            url = "https://igacoffice365-my.sharepoint.com/:f:/g/personal/andres_osorio_igac_gov_co/EkNGrqX35gFMgZCB3D6vTt0B1slsc-IY9g5zJyz3HAa1aA?e=KZWV1P"
            try:
                downloader = SharePointDownloader(gui)
                downloader.download_from_sharepoint(url)
            except Exception as e:
                print(f"Error en la descarga: {str(e)}")
                if gui:
                    gui.add_log(f"Error fatal: {str(e)}")
                    gui.enable_close()
        
        gui = DownloadProgressGUI()
        thread = threading.Thread(target=start_download, daemon=True)
        thread.start()
        gui.root.mainloop()
        
    except Exception as e:
        print(f"Error fatal en la ejecución: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()