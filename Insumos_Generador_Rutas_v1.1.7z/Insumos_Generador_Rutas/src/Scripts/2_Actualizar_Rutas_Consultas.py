import os
import pandas as pd
import sqlite3
from pathlib import Path
import re

def get_excel_file():
    script_path = Path(__file__)
    rutas_path = script_path.parent.parent / 'Rutas_Actualizadas'
    excel_files = list(rutas_path.glob('*.xlsx'))
    
    if not excel_files:
        raise FileNotFoundError("No se encontró archivo Excel en la carpeta Rutas_Actualizadas")
    
    return excel_files[0]

def create_db_connection():
    script_path = Path(__file__)
    db_path = script_path.parent.parent / 'db'
    db_path.mkdir(exist_ok=True)
    db_file = db_path / 'rutas.db'
    
    if db_file.exists():
        db_file.unlink()
    
    return sqlite3.connect(db_file)

def extract_mpio_code(ruta):
    try:
        # Buscar el patrón después de '_catas\'
        match = re.search(r'_catas\\([0-9]+)\\([0-9]+)\\', ruta)
        if match:
            # Obtener los dos grupos de números y concatenarlos
            codigo = match.group(1) + match.group(2)
            # Asegurar que tengamos 5 dígitos
            if len(codigo) == 5:
                return codigo
    except Exception:
        pass
    return None

def main():
    try:
        excel_file = get_excel_file()
        
        # Leer el Excel usando el índice de columna (C es índice 2)
        df = pd.read_excel(
            excel_file,
            sheet_name='Ruta2',
            usecols=[2],  # Columna C
            skiprows=1,
            header=None  # No usar primera fila como encabezado
        )
        
        # Renombrar la columna
        df.columns = ['ruta_completa']
        
        # Mostrar las primeras filas para debugging
        print("Primeras filas leídas:")
        print(df.head())
        
        # Extraer código de municipio de cada ruta
        df['codigo_mpio_rutas'] = df['ruta_completa'].apply(extract_mpio_code)
        
        # Eliminar filas donde no se pudo extraer el código
        df = df.dropna(subset=['codigo_mpio_rutas'])
        
        print("\nMuestra de datos procesados:")
        print(df.head())
        print("\nTotal de rutas procesadas:", len(df))
        
        # Crear conexión y guardar en la base de datos
        conn = create_db_connection()
        
        df.to_sql(
            'rutas', 
            conn, 
            index=False,
            dtype={
                'ruta_completa': 'TEXT',
                'codigo_mpio_rutas': 'TEXT'
            }
        )
        
        print(f"\nBase de datos actualizada exitosamente.")
        print(f"Se procesaron {len(df)} registros.")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        print(f"Ruta del archivo Excel:", get_excel_file())
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    main()