import sqlite3
import os
import pandas as pd
from datetime import datetime
import shutil
from pathlib import Path
import getpass
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill

class ExcelAutomator:
    def __init__(self):
        self.script_path = Path(__file__).resolve()
        self.project_root = self.script_path.parent.parent
        self.db_path = self.project_root / 'db' / 'registros_totales.db'
        self.template_dir = self.project_root / 'Plantilla_Reporte'
        self.output_dir = self.project_root.parent / 'Resultados'
        self.template_path = next(self.template_dir.glob('*.xlsx'))
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.error_log = self.output_dir / 'errores_proceso.txt'
        self.lock = threading.Lock()
        
        self.route_configs = {
            '06_insu': {
                'G9': {'rutas': [r'03_info_catas\01_r1_r2'], 'texto': '03_info_catas\\01_r1_r2'},
                'G10': {'rutas': [r'03_info_catas\02_gdb', r'03_info_catas\01_gdb_2022'], 'texto': '03_info_catas\\02_gdb'},
                'G11': {'rutas': [
                    r'01_carto_basic\01_rast\01_orto',
                    r'01_carto_basica\1_raster\01_orto',
                    r'01_carto_basica\1_raster'
                ], 'texto': '01_carto_basic\\01_rast\\01_orto'},
                'G12': {'rutas': [r'01_carto_basic\02_vect', r'01_carto_basic\2_vect'], 'texto': '01_carto_basic\\02_vect'},
                'G13': {'rutas': [r'03_info_catas\03_tab_terr_constr'], 'texto': '03_info_catas\\03_tab_terr_constr', 'optional': True},
                'G14': {'rutas': [r'03_info_catas\04_estu_zhf_zhg'], 'texto': '03_info_catas\\04_estu_zhf_zhg', 'optional': True},
                'G15': {'rutas': [
                    r'01_rast\02_dtm',
                    r'01_carto_basic\1_rast\02_dtm',
                    r'01_carto_basic\01_rast\02_dtm'
                ], 'texto': '01_rast\\02_dtm'},
                'G16': {'rutas': [r'04_deslin'], 'texto': '04_deslin'},
                'G17': {'rutas': [r'06_insu_regis'], 'texto': '06_insu_regis', 'optional': True}
            },
            '07_insu': {
                'G8': {'rutas': [r'08_inst_ord_terri'], 'texto': '08_inst_ord_terri'},
                'G9': {'rutas': [r'03_info_catas\01_r1_r2'], 'texto': '03_info_catas\\01_r1_r2'},
                'G10': {'rutas': [r'03_info_catas\02_gdb',r'03_info_catas\GDB'], 'texto': '03_info_catas\\02_gdb'},
                'G11': {'rutas': [r'01_carto_basic\01_rast\01_orto'], 'texto': '01_carto_basic\\01_rast\\01_orto'},
                'G12': {'rutas': [r'01_carto_basic\02_vect'], 'texto': '01_carto_basic\\02_vect'},
                'G13': {'rutas': [r'03_info_catas\03_tab_terr_constr',r'03_info_catas\03_tab_terre_constr_vigen'], 'texto': '03_info_catas\\03_tab_terr_constr'},
                'G14': {'rutas': [r'03_info_catas\04_estu_zhf_zhg', r'03_info_catas\04_estu_zhf_zhg_vigen'], 'texto': '03_info_catas\\04_estu_zhf_zhg'},
                'G15': {'rutas': [r'01_carto_basic\01_rast\02_dtm',r'01_carto_basic\1_rast\02_dtm'], 'texto': '01_carto_basic\\1_rast\\02_dtm'},
                'G16': {'rutas': [r'04_deslin'], 'texto': '04_deslin'},
                'G17': {'rutas': [r'06_insu_regis'], 'texto': '06_insu_regis'}
            }
        }

    def ensure_trailing_slash(self, path):
        return path if path.endswith('\\') else path + '\\'

    def log_error(self, municipio, ruta, error):
        with self.lock:
            with open(self.error_log, 'a', encoding='utf-8') as f:
                f.write(f"Municipio: {municipio}\nRuta: {ruta}\nError: {error}\n{'='*50}\n")

    def check_directory_status(self, directory):
        try:
            directory_path = Path(directory)
            if not directory_path.exists():
                return None
            
            items = list(directory_path.glob('*'))
            if not items:
                return False
            
            latest_date = None
            for item in items:
                try:
                    modified_time = os.path.getmtime(item)
                    current_date = datetime.fromtimestamp(modified_time)
                    if latest_date is None or current_date > latest_date:
                        latest_date = current_date
                except Exception:
                    continue
            
            return latest_date
        except Exception:
            return None

    def check_path_access(self, ruta_completa, route_type):
        if route_type not in self.route_configs:
            return 'no_access'
        
        ruta_completa = self.ensure_trailing_slash(ruta_completa)
        all_empty = True
        has_access = False
        results = {}
        
        config = self.route_configs[route_type]
        for cell_ref, path_info in config.items():
            path_found = False
            
            for ruta in path_info['rutas']:
                full_path = ruta_completa + ruta
                status = self.check_directory_status(full_path)
                
                if status is not None:
                    path_found = True
                    has_access = True
                    if status is not False:
                        all_empty = False
                    results[cell_ref] = {'path': full_path, 'status': status}
                    break
            
            if not path_found and not path_info.get('optional', False):
                results[cell_ref] = {'path': None, 'status': None}
        
        if not has_access:
            return 'no_access'
        if all_empty:
            return 'all_empty'
        return results

    def clean_filename(self, name):
        invalid_chars = '<>:"/\\|?*'
        clean_name = name
        for char in invalid_chars:
            clean_name = clean_name.replace(char, '')
        
        replacements = {
            'Ñ': 'N', 'ñ': 'n', 'Á': 'A', 'É': 'E', 'Í': 'I', 'Ó': 'O', 'Ú': 'U',
            'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', ' ': '_'
        }
        
        for old, new in replacements.items():
            clean_name = clean_name.replace(old, new)
        
        return clean_name

    def get_unique_filename(self, codigo_mpio, municipio):
        municipio = self.clean_filename(str(municipio).strip())
        base_name = f"{codigo_mpio}_{municipio}.xlsx"
        final_path = self.output_dir / base_name
        counter = 1
        
        while final_path.exists():
            base_name = f"{codigo_mpio}_{municipio}_{counter}.xlsx"
            final_path = self.output_dir / base_name
            counter += 1
        
        return final_path

    def get_user_name(self):
        return getpass.getuser()

    def format_date(self, date_str):
        try:
            if pd.isna(date_str):
                return ""
            date_obj = datetime.strptime(str(date_str), '%Y-%m-%d %H:%M:%S')
            return date_obj.strftime('%d/%m/%Y')
        except Exception as e:
            return str(date_str)

    def process_municipality(self, municipio_data):
        try:
            ruta_completa = municipio_data['ruta_completa']
            
            if pd.isna(ruta_completa):
                self.log_error(municipio_data['municipio'], "N/A", "Ruta no disponible")
                return
            
            route_type = '06_insu' if '06_insu' in ruta_completa else ('07_insu' if '07_insu' in ruta_completa else None)
            access_results = self.check_path_access(ruta_completa, route_type)
            
            if access_results == 'no_access':
                self.log_error(
                    municipio_data['municipio'],
                    ruta_completa,
                    "No se puede acceder a una o más rutas del municipio"
                )
                return
            elif access_results == 'all_empty':
                self.log_error(
                    municipio_data['municipio'],
                    ruta_completa,
                    "Todas las rutas existen pero están vacías"
                )
                return
            
            output_path = self.get_unique_filename(
                municipio_data['codigo_mpio'],
                municipio_data['municipio']
            )
            
            with self.lock:
                shutil.copy2(self.template_path, output_path)
            
            wb = load_workbook(output_path)
            ws = wb.active
            
            border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            center_alignment = Alignment(horizontal='center', vertical='center')
            hyperlink_font = Font(color='0000FF', underline='single')
            
            ws['B1'] = f"MATRIZ DE INSUMOS MUNICIPIO DE {municipio_data['municipio']}"
            ws['C3'] = municipio_data['codigo_mpio']
            ws['C4'] = municipio_data['en_operacion']
            ws['H3'] = self.format_date(municipio_data['fecha_inicio_operativa'])
            
            user_name = self.get_user_name()
            config = self.route_configs[route_type]
            
            for cell_ref, path_info in config.items():
                row = int(cell_ref[1:])
                result = access_results.get(cell_ref, {})
                
                # Aplicar estilos base a todas las celdas
                for col in ['F', 'G', 'I']:
                    cell = ws[f'{col}{row}']
                    cell.border = border
                    cell.alignment = center_alignment
                
                # Establecer el nombre de usuario
                ws[f'I{row}'] = user_name
                
                if result.get('path'):
                    # Si se encontró la ruta
                    cell = ws[f'G{row}']
                    cell.value = path_info['texto']
                    cell.hyperlink = result['path']
                    cell.font = hyperlink_font
                    cell.border = border
                    cell.alignment = center_alignment
                    
                    status = result['status']
                    ws[f'F{row}'] = status.strftime('%d/%m/%Y') if status else "Vacío"
                else:
                    # Si no se encontró la ruta
                    ws[f'F{row}'] = "Vacío"
                    cell = ws[f'G{row}']
                    cell.value = "Vacío"
                    cell.border = border
                    cell.alignment = center_alignment
            
            wb.save(output_path)
            
        except Exception as e:
            self.log_error(municipio_data['municipio'], ruta_completa, str(e))

    def process_all_municipalities(self):
        try:
            conn = sqlite3.connect(self.db_path)
            query = "SELECT * FROM municipios"
            df = pd.read_sql_query(query, conn)
            conn.close()
            
            total_municipios = len(df)
            processed_count = 0
            
            print(f"Iniciando procesamiento de {total_municipios} municipios...")
            
            max_workers = min(total_municipios, 10)
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_municipio = {
                    executor.submit(self.process_municipality, row.to_dict()): row['municipio']
                    for _, row in df.iterrows()
                }
                
                for future in as_completed(future_to_municipio):
                    municipio = future_to_municipio[future]
                    try:
                        future.result()
                    except Exception as e:
                        print(f"Error procesando {municipio}: {str(e)}")
                    
                    processed_count += 1
                    print(f"Progreso: {processed_count}/{total_municipios} municipios procesados")
            
            print("\nProcesamiento completado.")
            print(f"Revisa el archivo de errores en: {self.error_log}")
            
        except Exception as e:
            print(f"Error en el procesamiento general: {e}")

if __name__ == "__main__":
    try:
        automator = ExcelAutomator()
        automator.process_all_municipalities()
    except Exception as e:
        print(f"Error al iniciar el programa: {e}")