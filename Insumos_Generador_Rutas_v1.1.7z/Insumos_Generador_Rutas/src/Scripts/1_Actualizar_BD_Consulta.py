import os
import pandas as pd
import sqlite3
from pathlib import Path
from datetime import datetime
import sys

def get_excel_file():
    script_path = Path(__file__)
    plantilla_path = script_path.parent.parent / 'plantilla_actual'
    excel_files = list(plantilla_path.glob('*.xlsx'))
    
    if not excel_files:
        raise FileNotFoundError("No se encontró archivo Excel en la carpeta plantilla_actual")
    
    return excel_files[0]

def create_db_connection():
    script_path = Path(__file__)
    db_path = script_path.parent.parent / 'db'
    db_path.mkdir(exist_ok=True)
    db_file = db_path / 'municipios.db'
    
    if db_file.exists():
        db_file.unlink()
    
    return sqlite3.connect(db_file)

def main():
    try:
        excel_file = get_excel_file()
        print(f"Leyendo archivo Excel: {excel_file}")
        
        # Leer el filtro JSON si existe
        from pathlib import Path
        import json
        
        filter_file = Path(__file__).parent.parent / 'config' / 'selected_filters.json'
        filtros = None
        if filter_file.exists():
            with open(filter_file, 'r', encoding='utf-8') as f:
                filtros = json.load(f)
                print("Filtros cargados:", filtros)
        
        # Leer Excel con los nombres de columnas que sabemos que existen
        df = pd.read_excel(
            excel_file,
            sheet_name='Base_mpios_2024',
            skiprows=4,
            usecols=[
                'Código MPIO',
                'MUNICIPIO',
                'DEPARTAMENTO',
                'MODELO DE OPERACIÓN',
                'MECANISMO DE GESTIÓN DE RECURSOS',
                'LÍNEA BASE DE OPERACIÓN EN 2024\n177 MUNICIPIOS',
                'INICIO ETAPA OPERATIVA OP. DIRECTA / INICIO DE CONTRATO CON OPERADOR TERCERIZADO',
                'NUEVA PROPUESTA CIERRE 2024\nPROPUESTO DT'
            ]
        )
        
        print("Columnas encontradas:", df.columns.tolist())
        
        # Renombrar las columnas
        df = df.rename(columns={
            'Código MPIO': 'codigo_mpio',
            'MUNICIPIO': 'municipio',
            'DEPARTAMENTO': 'departamento',
            'MODELO DE OPERACIÓN': 'modelo_operacion',
            'MECANISMO DE GESTIÓN DE RECURSOS': 'mecanismo_gestion',
            'LÍNEA BASE DE OPERACIÓN EN 2024\n177 MUNICIPIOS': 'en_operacion',
            'INICIO ETAPA OPERATIVA OP. DIRECTA / INICIO DE CONTRATO CON OPERADOR TERCERIZADO': 'fecha_inicio_operativa',
            'NUEVA PROPUESTA CIERRE 2024\nPROPUESTO DT': 'propuesta_cierre'
        })

        # Procesar específicamente la columna propuesta_cierre
        df['propuesta_cierre'] = df['propuesta_cierre'].fillna(0)
        df['propuesta_cierre'] = df['propuesta_cierre'].replace('-', 0)
        df['propuesta_cierre'] = pd.to_numeric(
            df['propuesta_cierre'],
            errors='coerce'
        ).fillna(0).astype(int)
        
        print(f"Registros totales leídos: {len(df)}")
        
        # Aplicar filtros si existen
        if filtros:
            if filtros.get('departamento'):
                df = df[df['departamento'].isin(filtros['departamento'])]
            if filtros.get('municipio'):
                df = df[df['municipio'].isin(filtros['municipio'])]
            if filtros.get('modelo'):
                df = df[df['modelo_operacion'].isin(filtros['modelo'])]
            if filtros.get('mecanismo'):
                df = df[df['mecanismo_gestion'].isin(filtros['mecanismo'])]
            if filtros.get('propuesta_cierre'):
                valores_filtro = [int(x) for x in filtros['propuesta_cierre']]
                print(f"Valores únicos en propuesta_cierre antes de filtrar: {df['propuesta_cierre'].unique()}")
                print(f"Aplicando filtro de propuesta_cierre con valores: {valores_filtro}")
                df = df[df['propuesta_cierre'].isin(valores_filtro)]
            
            print(f"Registros después de filtrar: {len(df)}")
        
        # Limpieza y transformación de datos
        df['codigo_mpio'] = df['codigo_mpio'].astype(str)
        df['en_operacion'] = df['en_operacion'].notna().map({True: 'Sí', False: 'No'})
        df['fecha_inicio_operativa'] = pd.to_datetime(
            df['fecha_inicio_operativa'],
            format='%d/%m/%Y',
            errors='coerce'
        )
        df['modelo_operacion'] = df['modelo_operacion'].fillna('No especificado')
        df['mecanismo_gestion'] = df['mecanismo_gestion'].fillna('No especificado')
        
        # Crear conexión y guardar en la BD
        conn = create_db_connection()
        
        # Guardar en la base de datos
        df.to_sql(
            'municipios',
            conn,
            index=False,
            if_exists='replace',
            dtype={
                'codigo_mpio': 'TEXT',
                'municipio': 'TEXT',
                'departamento': 'TEXT',
                'modelo_operacion': 'TEXT',
                'mecanismo_gestion': 'TEXT',
                'en_operacion': 'TEXT',
                'fecha_inicio_operativa': 'DATE',
                'propuesta_cierre': 'INTEGER'
            }
        )
        
        # Verificar que se guardaron los datos
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM municipios")
        count = cursor.fetchone()[0]
        
        print(f"\nBase de datos actualizada exitosamente.")
        print(f"Se procesaron y guardaron {count} registros.")
        
        # Mostrar algunos registros para verificación
        print("\nPrimeros 5 registros guardados:")
        cursor.execute("SELECT * FROM municipios LIMIT 5")
        for row in cursor.fetchall():
            print(row)
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        print(traceback.format_exc())
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    main()