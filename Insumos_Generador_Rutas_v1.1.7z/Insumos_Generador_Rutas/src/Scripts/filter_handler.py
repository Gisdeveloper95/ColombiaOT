from pathlib import Path
import json
import sqlite3
import pandas as pd

class FilterHandler:
    def __init__(self):
        self.script_path = Path(__file__).parent
        self.project_root = self.script_path.parent  # Removido un .parent
        self.filters_path = self.project_root / 'config'
        self.filters_path.mkdir(exist_ok=True)
        self.filters_file = self.filters_path / 'selected_filters.json'
        self._current_filters = None
        

    def get_filtered_municipalities(self):
        """Obtiene los municipios filtrados de la base de datos"""
        filters = self.load_filters()
        if not filters:
            return []
            
        # Cambiado para usar municipios.db en lugar de registros_totales.db
        db_path = self.project_root / 'db' / 'municipios.db'
        
        try:
            conn = sqlite3.connect(db_path)
            query = """
                SELECT DISTINCT m.* 
                FROM municipios m
                WHERE 1=1
            """
            params = []
            
            if filters.get('departamento'):
                query += " AND m.departamento IN ({})".format(
                    ','.join(['?' for _ in filters['departamento']])
                )
                params.extend(filters['departamento'])
                
            if filters.get('municipio'):
                query += " AND m.municipio IN ({})".format(
                    ','.join(['?' for _ in filters['municipio']])
                )
                params.extend(filters['municipio'])
                
            if filters.get('modelo'):
                query += " AND m.modelo_operacion IN ({})".format(
                    ','.join(['?' for _ in filters['modelo']])
                )
                params.extend(filters['modelo'])
                
            if filters.get('mecanismo'):
                query += " AND m.mecanismo_gestion IN ({})".format(
                    ','.join(['?' for _ in filters['mecanismo']])
                )
                params.extend(filters['mecanismo'])
            
            if filters.get('propuesta_cierre'):
                valores = [str(x) for x in filters['propuesta_cierre']]
                query += " AND (CASE WHEN m.propuesta_cierre = '-' OR m.propuesta_cierre IS NULL THEN '0' ELSE m.propuesta_cierre END) IN ({})".format(
                    ','.join(['?' for _ in valores])
                )
                params.extend(valores)
            
            df = pd.read_sql_query(query, conn, params=params)
            
            # Guardar los resultados filtrados para que otros scripts los usen
            filtered_db_path = self.project_root / 'db' / 'municipios_filtered.db'
            filtered_conn = sqlite3.connect(filtered_db_path)
            df.to_sql('municipios', filtered_conn, index=False, if_exists='replace')
            filtered_conn.close()
            
            return df
            
        except Exception as e:
            print(f"Error al obtener municipios filtrados: {e}")
            return pd.DataFrame()
        finally:
            if 'conn' in locals():
                conn.close()
    
    def save_filters(self, filters):
        """Guarda los filtros seleccionados en un archivo JSON y en memoria"""
        self._current_filters = filters.copy()  # Guardar en memoria
        with open(self.filters_file, 'w', encoding='utf-8') as f:
            json.dump(filters, f, ensure_ascii=False, indent=4)

    def load_filters(self):
        """Carga los filtros desde el archivo JSON o memoria"""
        if self._current_filters is not None:
            return self._current_filters
        if not self.filters_file.exists():
            return None
        with open(self.filters_file, 'r', encoding='utf-8') as f:
            self._current_filters = json.load(f)
            return self._current_filters

    def clear_filters(self):
        """Limpia los filtros en memoria y archivo"""
        self._current_filters = None
        if self.filters_file.exists():
            self.filters_file.unlink()