import sqlite3
import os
import pandas as pd
from datetime import datetime
import shutil
from pathlib import Path
import getpass
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill


        
class ExcelAutomator:
    def __init__(self):
        self.script_path = Path(__file__).resolve()
        self.project_root = self.script_path.parent.parent
        self.db_path = self.project_root / 'db' / 'registros_totales_post.db'
        self.template_dir = self.project_root / 'Plantilla_Post'
        self.output_dir = self.project_root.parent / 'Resultados_Post'
        self.template_path = next(self.template_dir.glob('*.xlsx'))
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.error_log = self.output_dir / 'errores_proceso_post.txt'
        self.lock = threading.Lock()
        # Nueva estructura para las rutas
        self.routes = self.initialize_routes()

    def initialize_routes(self):
        """Inicializa la estructura de rutas completa basada en el CSV"""
        routes = [
            # 1-3: Grupo 01_aprob_econo/01_info_tecn_ZHG
            {
                'components': ['01_aprob_econo', '01_info_tecn_ZHG', '01_analis_sensib', '-'],
                'row': 8
            },
            {
                'components': ['01_aprob_econo', '01_info_tecn_ZHG', '02_proyec_avalu', '-'],
                'row': 9
            },
            {
                'components': ['01_aprob_econo', '01_info_tecn_ZHG', '03_tab_terr_const', '-'],
                'row': 10
            },
            # 4-5: Acta y concepto
            {
                'components': ['01_aprob_econo', '02_acta_comit', '-', '-'],
                'row': 11
            },
            {
                'components': ['01_aprob_econo', '03_conc_favor', '-', '-'],
                'row': 12
            },
            # 6-9: Memorandos técnicos
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '01_plan', '-'],
                'row': 13
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '01_plan', '-'],
                'row': 14
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '02_zhf', '-'],
                'row': 15
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '03_zhg', '-'],
                'row': 16
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '04_form', '-'],
                'row': 17
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '04_form', '-'],
                'row': 18
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '04_form', '-'],
                'row': 19
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '04_memo', '-'],
                'row': 20
            },
            {
                'components': ['01_aprob_econo', '04_memo_tecn_estu_econo', '04_memo', '-'],
                'row': 21
            },
            # 10-13: Comunicaciones y resoluciones
            {
                'components': ['01_aprob_econo', '05_comuni_adopc_porc_aval_catas', '-', '-'],
                'row': 22
            },
            {
                'components': ['01_aprob_econo', '06_resol_aprob', '01_resol', '-'],
                'row': 23
            },
            {
                'components': ['01_aprob_econo', '06_resol_aprob', '02_publi_dia_ofic', '-'],
                'row': 24
            },
            {
                'components': ['01_aprob_econo', '06_resol_aprob', '03_ofic_comuni', '-'],
                'row': 25
            },
            # 14-17: Componente social
            {
                'components': ['02_comp_soci', '01_niv_interloc_iv', '01_info', '-'],
                'row': 26
            },
            {
                'components': ['02_comp_soci', '01_niv_interloc_iv', '02_regis_foto', '-'],
                'row': 27
            },
            {
                'components': ['02_comp_soci', '01_niv_interloc_iv', '03_list_asis', '-'],
                'row': 28
            },
            {
                'components': ['02_comp_soci', '01_niv_interloc_iv', '04_difu', '-'],
                'row': 29
            },
            # 18-22: Pre-cierre
            {
                'components': ['03_pre_cie', '01_eviden_atenc_sald', '-', '-'],
                'row': 30
            },
            {
                'components': ['03_pre_cie', '02_repor_cica_fin', '-', '-'],
                'row': 31
            },
            {
                'components': ['03_pre_cie', '03_base_renum', '-', '-'],
                'row': 32
            },
            {
                'components': ['03_pre_cie', '04_tab_ph', '-', '-'],
                'row': 33
            },
            {
                'components': ['03_pre_cie', '05_preli', '-', '-'],
                'row': 34
            },
            # 23-25: Resoluciones de inscripción
            {
                'components': ['04_resol_insc', '01_resol', '-', '-'],
                'row': 35
            },
            {
                'components': ['04_resol_insc', '02_publi_dia_ofi', '-', '-'],
                'row': 36
            },
            {
                'components': ['04_resol_insc', '03_ofi_comun_resol', '-', '-'],
                'row': 37
            },
            # 26-30: Productos catastrales
            {
                'components': ['05_prod_catas', '01_list_pred_actualiz', '-', '-'],
                'row': 38
            },
            {
                'components': ['05_prod_catas', '02_mem_tecn_actualiz', '-', '-'],
                'row': 39
            },
            {
                'components': ['05_prod_catas', '03_r1_r2', '-', '-'],
                'row': 40
            },
            {
                'components': ['05_prod_catas', '04_gdb', '-', '-'],
                'row': 41
            },
            {
                'components': ['05_prod_catas', '05_xtf', '-', '-'],
                'row': 42
            },
            # 31-32: Actas de entrega
            {
                'components': ['06_acta_entreg_base_catas', '-', '-', '-'],
                'row': 43
            },
            {
                'components': ['07_acta_entreg_prod_catas', '-', '-', '-'],
                'row': 44
            }
        ]
        return routes


    def log_error(self, municipio, ruta, error):
        """Registra errores en el archivo de log"""
        with self.lock:
            with open(self.error_log, 'a', encoding='utf-8') as f:
                f.write(f"Municipio: {municipio}\nRuta: {ruta}\nError: {error}\n{'='*50}\n")

    def clean_filename(self, name):
        """Limpia el nombre del archivo de caracteres inválidos"""
        invalid_chars = '<>:"/\\|?*'
        clean_name = name
        for char in invalid_chars:
            clean_name = clean_name.replace(char, '')
        
        replacements = {
            'Ñ': 'N', 'ñ': 'n', 'Á': 'A', 'É': 'E', 'Í': 'I', 'Ó': 'O', 'Ú': 'U',
            'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', ' ': '_'
        }
        
        for old, new in replacements.items():
            clean_name = clean_name.replace(old, new)
        
        return clean_name

    def get_unique_filename(self, codigo_mpio, municipio):
        """Genera un nombre único para el archivo de salida"""
        municipio = self.clean_filename(str(municipio).strip())
        current_date = datetime.now()
        date_suffix = f"{current_date.day:02d}_{current_date.month:02d}_{current_date.year}"
        base_name = f"{codigo_mpio}_{municipio}_{date_suffix}.xlsx"
        final_path = self.output_dir / base_name
        counter = 1
        
        while final_path.exists():
            base_name = f"{codigo_mpio}_{municipio}_{date_suffix}_{counter}.xlsx"
            final_path = self.output_dir / base_name
            counter += 1
        
        return final_path

    def get_user_name(self):
        """Obtiene el nombre del usuario actual"""
        return getpass.getuser()

    def format_date(self, date_str):
        """Formatea una fecha a string en formato dd/mm/yyyy"""
        try:
            if pd.isna(date_str):
                return ""
            date_obj = datetime.strptime(str(date_str), '%Y-%m-%d %H:%M:%S')
            return date_obj.strftime('%d/%m/%Y')
        except Exception as e:
            return str(date_str)

    def build_path(self, base_path, components):
        """Construye la ruta completa basada en los componentes no vacíos"""
        valid_components = [c for c in components if c != '-']
        return Path(base_path) / '/'.join(valid_components)

    def get_directory_info(self, directory):
        """Obtiene información sobre el directorio: existencia, archivos y fechas"""
        try:
            dir_path = Path(directory)
            if not dir_path.exists():
                return {
                    'exists': False,
                    'has_files': False,
                    'latest_date': None,
                    'files_list': []
                }

            all_files = []
            latest_date = None
            
            for item in dir_path.rglob('*'):
                if item.is_file():
                    all_files.append(item.name)
                    mod_time = datetime.fromtimestamp(item.stat().st_mtime)
                    if latest_date is None or mod_time > latest_date:
                        latest_date = mod_time

            return {
                'exists': True,
                'has_files': len(all_files) > 0,
                'latest_date': latest_date,
                'files_list': all_files
            }
        except Exception as e:
            self.log_error(str(directory), "Error", str(e))
            return {
                'exists': False,
                'has_files': False,
                'latest_date': None,
                'files_list': []
            }

    def process_municipality(self, municipio_data):
        """Procesa un municipio y genera su excel correspondiente"""
        try:
            ruta_completa = municipio_data['ruta_completa']
            if pd.isna(ruta_completa):
                self.log_error(municipio_data['municipio'], "N/A", "Ruta no disponible")
                return

            output_path = self.get_unique_filename(
                municipio_data['codigo_mpio'],
                municipio_data['municipio']
            )

            with self.lock:
                shutil.copy2(self.template_path, output_path)

            wb = load_workbook(output_path)
            ws = wb["MATRIZ_DISPO_INFO"]

            # Información básica
            ws['B1'] = f"MATRIZ DE DISPOSICION DE LA INFORMACION PARA EL MUNICIPIO DE {municipio_data['municipio']}"
            ws['C3'] = municipio_data['codigo_mpio']
            ws['C4'] = municipio_data['en_operacion']
            ws['H3'] = self.format_date(municipio_data['fecha_inicio_operativa'])

            user_name = self.get_user_name()

            # Procesar cada ruta
            for route in self.routes:
                row = route['row']
                full_path = self.build_path(ruta_completa, route['components'])
                dir_info = self.get_directory_info(full_path)

                # Llenar columnas
                ws[f'F{row}'] = 'SI' if dir_info['has_files'] else 'NO'
                ws[f'G{row}'] = (dir_info['latest_date'].strftime('%d/%m/%Y') 
                                if dir_info['latest_date'] else '-')
                ws[f'H{row}'] = str(full_path) if dir_info['has_files'] else 'Vacio'
                ws[f'K{row}'] = user_name
                ws[f'L{row}'] = ';'.join(dir_info['files_list']) if dir_info['files_list'] else '-'

            wb.save(output_path)

        except Exception as e:
            self.log_error(municipio_data['municipio'], ruta_completa, str(e))

    def process_all_municipalities(self):
        """Procesa todos los municipios en la base de datos"""
        try:
            conn = sqlite3.connect(self.db_path)
            query = "SELECT * FROM municipios"
            df = pd.read_sql_query(query, conn)
            conn.close()
            
            total_municipios = len(df)
            processed_count = 0
            
            print(f"Iniciando procesamiento de {total_municipios} municipios...")
            
            max_workers = min(total_municipios, 10)
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_municipio = {
                    executor.submit(self.process_municipality, row.to_dict()): row['municipio']
                    for _, row in df.iterrows()
                }
                
                for future in as_completed(future_to_municipio):
                    municipio = future_to_municipio[future]
                    try:
                        future.result()
                    except Exception as e:
                        print(f"Error procesando {municipio}: {str(e)}")
                    
                    processed_count += 1
                    print(f"Progreso: {processed_count}/{total_municipios} municipios procesados")
            
            print("\nProcesamiento completado.")
            print(f"Revisa el archivo de errores en: {self.error_log}")
            
        except Exception as e:
            print(f"Error en el procesamiento general: {e}")



    def ensure_trailing_slash(self, path):
        return path if path.endswith('\\') else path + '\\'

    def check_path_access(self, ruta_completa, route_type):
        if route_type not in self.route_configs:
            return 'no_access'
        
        ruta_completa = self.ensure_trailing_slash(ruta_completa)
        all_empty = True
        has_access = False
        results = {}
        
        config = self.route_configs[route_type]
        for cell_ref, path_info in config.items():
            path_found = False
            
            for ruta in path_info['rutas']:
                full_path = ruta_completa + ruta
                status = self.check_directory_status(full_path)
                
                if status is not None:
                    path_found = True
                    has_access = True
                    if status is not False:
                        all_empty = False
                    results[cell_ref] = {'path': full_path, 'status': status}
                    break
            
            if not path_found and not path_info.get('optional', False):
                results[cell_ref] = {'path': None, 'status': None}
        
        if not has_access:
            return 'no_access'
        if all_empty:
            return 'all_empty'
        return results

    def check_directory_status(self, directory):
        try:
            directory_path = Path(directory)
            if not directory_path.exists():
                return 'no_existe'
            
            items = list(directory_path.glob('*'))
            if not items:
                return 'vacio'
            
            latest_date = None
            for item in items:
                try:
                    modified_time = os.path.getmtime(item)
                    current_date = datetime.fromtimestamp(modified_time)
                    if latest_date is None or current_date > latest_date:
                        latest_date = current_date
                except Exception:
                    continue
            
            return latest_date
        except Exception:
            return 'no_existe'


def main():
    """Función principal"""
    try:
        automator = ExcelAutomator()
        automator.process_all_municipalities()
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error al iniciar el programa: {e}")